#!/usr/bin/env python3
"""TTS Voices 2.0 – Unlimited Text-to-Speech Engine for Linux"""
import os, sys, json, threading, queue, time, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

# ── Semantic versioning ────────────────────────────────────────────────────
__version__   = "2.1.0"
VERSION_TUPLE = (2, 1, 0)
VERSION_DATE  = "2026-03-21"
APP_NAME      = "TTS Voices"

# ── Clear stale bytecode before importing any local modules ──────────────────
# This prevents old .pyc files from silently running outdated buggy code
_APP_DIR = os.path.dirname(os.path.abspath(__file__))
_CACHE   = os.path.join(_APP_DIR, "__pycache__")
if os.path.exists(_CACHE):
    import shutil as _shutil
    try:
        _shutil.rmtree(_CACHE)
    except Exception:
        pass  # Non-fatal - app continues even if cache can't be cleared
# ─────────────────────────────────────────────────────────────────────────────

sys.path.insert(0, _APP_DIR)

# Suppress harmless PDF font warnings from pdfplumber/pypdf
import warnings as _warnings
_warnings.filterwarnings("ignore", message=".*FontBBox.*")
_warnings.filterwarnings("ignore", message=".*font descriptor.*")
_warnings.filterwarnings("ignore", message=".*Cannot parse.*floats.*")
_warnings.filterwarnings("ignore", category=UserWarning, module="pdfplumber")
_warnings.filterwarnings("ignore", category=UserWarning, module="pypdf")

import bug_tracker, voices, audio_handler, file_extractor
from save_point_manager import SavePointManager

CONFIG_DIR  = Path.home() / ".ttsvoices"
CONFIG_FILE = CONFIG_DIR / "config.json"
CONFIG_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_CONFIG = {"speed":1.3,"pitch":1.0,"volume":63,"voice_idx":0,"theme":"dark","provider":"CPU","bookmark_chunk":0,"bookmark_file":"","highlight_offset":150}

# ══════════════════════════════════════════════════════════════════════════════
#  THEME PALETTES
# ══════════════════════════════════════════════════════════════════════════════
THEMES = {
    "dark": {
        "label":"🌑 Dark",
        "bg":"#080c18","surface":"#0d1526","surface2":"#111e33","border":"#1a2a45",
        "border2":"#223055","accent":"#1a6cf5","accent2":"#00c8ff","accent_dim":"#0d3d99",
        "text":"#dde4f0","text2":"#8fa3c4","muted":"#4a6080","success":"#00d97e",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#1553d0","speak_hover":"#1d6aff",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#060a14","nav_btn":"#111e33",
        "nav_hover":"#1a2a45","textarea_bg":"#0d1526","textarea_fg":"#dde4f0",
        "scrollbar":"#111e33","cursor":"#00c8ff","sel_bg":"#0d3d99","pill_bg":"#041008",
    },
    "light": {
        "label":"☀ Light",
        "bg":"#f0f4f8","surface":"#ffffff","surface2":"#e8edf4","border":"#c8d4e4",
        "border2":"#b0c0d8","accent":"#1a6cf5","accent2":"#0d5cd4","accent_dim":"#d6e4ff",
        "text":"#0d1526","text2":"#3a5070","muted":"#7a94b0","success":"#1a9e5a",
        "warning":"#c47a00","error":"#c0392b","speak_bg":"#1553d0","speak_hover":"#1d6aff",
        "stop_bg":"#c0392b","stop_hover":"#e74c3c","header_bg":"#1a2a45","nav_btn":"#dce6f5",
        "nav_hover":"#c8d8f0","textarea_bg":"#ffffff","textarea_fg":"#0d1526",
        "scrollbar":"#dce6f5","cursor":"#1a6cf5","sel_bg":"#c8d8f0","pill_bg":"#f0fff4",
    },
    "red": {
        "label":"🔴 Red",
        "bg":"#0f0608","surface":"#1a0a0e","surface2":"#240d14","border":"#3d1520",
        "border2":"#5c1f2e","accent":"#e53e3e","accent2":"#ff6b6b","accent_dim":"#7a1a1a",
        "text":"#f5dde0","text2":"#c49098","muted":"#7a4a50","success":"#00d97e",
        "warning":"#f59e0b","error":"#ff3333","speak_bg":"#c0392b","speak_hover":"#e53e3e",
        "stop_bg":"#3d1520","stop_hover":"#6b2030","header_bg":"#0a0406","nav_btn":"#1a0a0e",
        "nav_hover":"#2d0e16","textarea_bg":"#1a0a0e","textarea_fg":"#f5dde0",
        "scrollbar":"#240d14","cursor":"#ff6b6b","sel_bg":"#5c1f2e","pill_bg":"#0f0608",
    },
    "blue": {
        "label":"🔵 Blue",
        "bg":"#040c1a","surface":"#071428","surface2":"#0a1c38","border":"#0e2d5c",
        "border2":"#133a78","accent":"#2980f5","accent2":"#5bb8ff","accent_dim":"#0d3080",
        "text":"#d8e8ff","text2":"#7aaad4","muted":"#3a6090","success":"#00d97e",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#0d3d99","speak_hover":"#1d6aff",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#020810","nav_btn":"#071428",
        "nav_hover":"#0e2d5c","textarea_bg":"#071428","textarea_fg":"#d8e8ff",
        "scrollbar":"#0a1c38","cursor":"#5bb8ff","sel_bg":"#0d3d99","pill_bg":"#020810",
    },
    "teal": {
        "label":"🩵 Teal",
        "bg":"#040f0f","surface":"#081a1a","surface2":"#0c2424","border":"#0e3838",
        "border2":"#155050","accent":"#00b8a9","accent2":"#00e5d4","accent_dim":"#006060",
        "text":"#d0f0ee","text2":"#70b8b0","muted":"#306860","success":"#00d97e",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#007a70","speak_hover":"#00b8a9",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#020a0a","nav_btn":"#081a1a",
        "nav_hover":"#0e3838","textarea_bg":"#081a1a","textarea_fg":"#d0f0ee",
        "scrollbar":"#0c2424","cursor":"#00e5d4","sel_bg":"#0e3838","pill_bg":"#020a0a",
    },
    "orange": {
        "label":"🟠 Orange",
        "bg":"#0f0900","surface":"#1a1000","surface2":"#261700","border":"#402800",
        "border2":"#5c3a00","accent":"#f57c00","accent2":"#ffaa33","accent_dim":"#7a3a00",
        "text":"#fff0d8","text2":"#c4a060","muted":"#806040","success":"#00d97e",
        "warning":"#ffcc00","error":"#ef4444","speak_bg":"#c06000","speak_hover":"#f57c00",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#0a0600","nav_btn":"#1a1000",
        "nav_hover":"#2d1e00","textarea_bg":"#1a1000","textarea_fg":"#fff0d8",
        "scrollbar":"#261700","cursor":"#ffaa33","sel_bg":"#5c3a00","pill_bg":"#0a0600",
    },
    "purple": {
        "label":"🟣 Purple",
        "bg":"#0a0615","surface":"#110920","surface2":"#180d2e","border":"#2a1550",
        "border2":"#3d2070","accent":"#8b5cf6","accent2":"#c084fc","accent_dim":"#4a1fa0",
        "text":"#eddeff","text2":"#a880d0","muted":"#604888","success":"#00d97e",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#5b21b6","speak_hover":"#7c3aed",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#07040f","nav_btn":"#110920",
        "nav_hover":"#2a1550","textarea_bg":"#110920","textarea_fg":"#eddeff",
        "scrollbar":"#180d2e","cursor":"#c084fc","sel_bg":"#3d2070","pill_bg":"#07040f",
    },
    "pink": {
        "label":"🩷 Pink",
        "bg":"#0f0610","surface":"#1a0c1c","surface2":"#241228","border":"#3d1545",
        "border2":"#5a2060","accent":"#ec4899","accent2":"#f9a8d4","accent_dim":"#831843",
        "text":"#ffe0f0","text2":"#c480a0","muted":"#804868","success":"#00d97e",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#9d174d","speak_hover":"#be185d",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#0a040c","nav_btn":"#1a0c1c",
        "nav_hover":"#3d1545","textarea_bg":"#1a0c1c","textarea_fg":"#ffe0f0",
        "scrollbar":"#241228","cursor":"#f9a8d4","sel_bg":"#5a2060","pill_bg":"#0a040c",
    },
    "golden": {
        "label":"✨ Golden",
        "bg":"#000000","surface":"#110a00","surface2":"#1a1000","border":"#5a3a00",
        "border2":"#7a5200","accent":"#ffb300","accent2":"#ffd700","accent_dim":"#3d2800",
        "text":"#fff5cc","text2":"#ffcc55","muted":"#907040","success":"#00d97e",
        "warning":"#ffcc00","error":"#ef4444","speak_bg":"#ffaa00","speak_hover":"#ffc533",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#0a0600","nav_btn":"#1a1000",
        "nav_hover":"#2a1a00","textarea_bg":"#0d0800","textarea_fg":"#fff5cc",
        "scrollbar":"#1a1000","cursor":"#ffd700","sel_bg":"#3d2800","pill_bg":"#0a0600",
    },
    "green": {
        "label":"🟢 Green",
        "bg":"#040f06","surface":"#081a0c","surface2":"#0c2414","border":"#0e3818",
        "border2":"#155024","accent":"#22c55e","accent2":"#4ade80","accent_dim":"#0a5c28",
        "text":"#d8ffe0","text2":"#70b880","muted":"#306840","success":"#4ade80",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#166534","speak_hover":"#16a34a",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#020a04","nav_btn":"#081a0c",
        "nav_hover":"#0e3818","textarea_bg":"#081a0c","textarea_fg":"#d8ffe0",
        "scrollbar":"#0c2414","cursor":"#4ade80","sel_bg":"#0e3818","pill_bg":"#020a04",
    },
    "studio": {
        "label":"🎨 Studio",
        "bg":"#0c0e13","surface":"#131929","surface2":"#1a2236","border":"#00c8b4",
        "border2":"#0a8f82","accent":"#00c8b4","accent2":"#29dfd0","accent_dim":"#0a4a44",
        "text":"#e8eef5","text2":"#8fa8c4","muted":"#4a5a70","success":"#00d97e",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#007a6e","speak_hover":"#00c8b4",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#0a0c10","nav_btn":"#131929",
        "nav_hover":"#1a2236","textarea_bg":"#0f1520","textarea_fg":"#e8eef5",
        "scrollbar":"#1a2236","cursor":"#29dfd0","sel_bg":"#0a4a44","pill_bg":"#0a0c10",
    },
    "midnight": {
        "label":"🌙 Midnight",
        "bg":"#000000","surface":"#050510","surface2":"#0a0a1a","border":"#1a1a3a",
        "border2":"#252550","accent":"#6c63ff","accent2":"#a78bfa","accent_dim":"#2d2a6e",
        "text":"#e8e0ff","text2":"#9d8fff","muted":"#4a4580","success":"#00d97e",
        "warning":"#f59e0b","error":"#ef4444","speak_bg":"#4c3fcf","speak_hover":"#6c63ff",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#000000","nav_btn":"#050510",
        "nav_hover":"#0f0f25","textarea_bg":"#020208","textarea_fg":"#e8e0ff",
        "scrollbar":"#0a0a1a","cursor":"#a78bfa","sel_bg":"#1a1a3a","pill_bg":"#000000",
    },
    "crimson": {
        "label":"🩸 Crimson",
        "bg":"#000000","surface":"#100008","surface2":"#180010","border":"#3a0018",
        "border2":"#580025","accent":"#dc143c","accent2":"#ff4d70","accent_dim":"#5a0018",
        "text":"#ffe0e8","text2":"#d080a0","muted":"#6a3050","success":"#00d97e",
        "warning":"#f59e0b","error":"#ff3333","speak_bg":"#b01030","speak_hover":"#dc143c",
        "stop_bg":"#3a0018","stop_hover":"#5a0025","header_bg":"#000000","nav_btn":"#100008",
        "nav_hover":"#200010","textarea_bg":"#080005","textarea_fg":"#ffe0e8",
        "scrollbar":"#180010","cursor":"#ff4d70","sel_bg":"#3a0018","pill_bg":"#000000",
    },
    "yellow": {
        "label":"🟡 Yellow",
        "bg":"#000000","surface":"#111100","surface2":"#1c1c00","border":"#4a4800",
        "border2":"#6a6600","accent":"#ffee00","accent2":"#ffff55","accent_dim":"#3a3400",
        "text":"#fffce0","text2":"#ffe066","muted":"#888840","success":"#00d97e",
        "warning":"#ffcc00","error":"#ef4444","speak_bg":"#ffe000","speak_hover":"#ffff44",
        "stop_bg":"#7a1515","stop_hover":"#c0392b","header_bg":"#0a0a00","nav_btn":"#1a1a00",
        "nav_hover":"#2a2a00","textarea_bg":"#0d0d00","textarea_fg":"#fffce0",
        "scrollbar":"#1c1c00","cursor":"#ffff55","sel_bg":"#3a3400","pill_bg":"#0a0a00",
    },
}

C = dict(THEMES["dark"])   # live colour dict – mutated on theme switch

FONT_LABEL = ("Courier New", 8, "bold")
FONT_BTN   = ("Courier New", 9, "bold")

def load_config():
    try:
        if CONFIG_FILE.exists():
            data = json.load(open(CONFIG_FILE))
            merged = {**DEFAULT_CONFIG, **data}
            # Migrate old 32767-scale or zero volume to sensible default
            vol = merged.get("volume", 63)
            if vol > 100:
                vol = max(1, int(vol / 327.67))
            if vol == 0:
                vol = 63
            merged["volume"] = vol
            return merged
    except Exception: pass
    return dict(DEFAULT_CONFIG)

def save_config(cfg):
    try: json.dump(cfg, open(CONFIG_FILE,"w"), indent=2)
    except Exception as e: bug_tracker.warning(f"Config save: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  CUSTOM FILE DIALOG
# ══════════════════════════════════════════════════════════════════════════════
class TTSFileDialog:
    BOOKMARKS = [
        ("⌂  Home",       Path.home()),
        ("⬇  Downloads",  Path.home()/"Downloads"),
        ("⬡  Documents",  Path.home()/"Documents"),
        ("⬡  Desktop",    Path.home()/"Desktop"),
    ]
    EXT_ICONS = {
        ".pdf":"📄",".docx":"📝",".doc":"📝",".epub":"📖",
        ".txt":"📃",".md":"📃",".html":"🌐",".htm":"🌐",
        ".rtf":"📝",".odt":"📝",".csv":"📊",
    }

    def __init__(self, parent):
        self.result = None
        self._cur   = Path.home()
        self.win    = tk.Toplevel(parent)
        self.win.title("Load Document")
        self.win.geometry("880x540")
        self.win.configure(bg=C["bg"])
        self.win.resizable(True, True)
        self.win.transient(parent)
        self._items = []
        self._build()
        self._go(self._cur)
        self.win.update()
        self.win.grab_set()
        self.win.focus_force()
        self.win.wait_window()

    def _build(self):
        # Header bar
        top = tk.Frame(self.win, bg=C["header_bg"], pady=10)
        top.pack(fill="x")
        tk.Label(top, text="Load Document", font=("Courier New",11,"bold"),
                 fg=C["accent2"], bg=C["header_bg"]).pack(side="left", padx=16)
        pf = tk.Frame(top, bg=C["surface2"],
                      highlightthickness=1, highlightbackground=C["border"])
        pf.pack(side="left", fill="x", expand=True, padx=10, ipady=3)
        self._path_var = tk.StringVar(value=str(self._cur))
        pe = tk.Entry(pf, textvariable=self._path_var,
                      bg=C["surface2"], fg=C["text"],
                      insertbackground=C["cursor"],
                      relief="flat", font=("Courier New",9), bd=4)
        pe.pack(fill="x")
        pe.bind("<Return>", lambda _: self._go(Path(self._path_var.get())))
        tk.Button(top, text=" Go ", font=("Courier New",8,"bold"),
                  bg=C["accent"], fg="white", relief="flat",
                  command=lambda: self._go(Path(self._path_var.get())),
                  activebackground=C["speak_hover"],
                  activeforeground="white").pack(side="left", padx=(0,14), ipady=4)

        # Body
        body = tk.Frame(self.win, bg=C["bg"])
        body.pack(fill="both", expand=True)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # Sidebar
        sb = tk.Frame(body, bg=C["surface"], width=165,
                      highlightthickness=1, highlightbackground=C["border"])
        sb.grid(row=0, column=0, sticky="nsew")
        sb.pack_propagate(False)
        tk.Label(sb, text="BOOKMARKS", font=("Courier New",7,"bold"),
                 fg=C["accent2"], bg=C["surface"], pady=8).pack(fill="x", padx=12)
        tk.Frame(sb, bg=C["border"], height=1).pack(fill="x", padx=8)
        for label, path in self.BOOKMARKS:
            if path.exists():
                b = tk.Button(sb, text=label, font=("Courier New",9),
                              fg=C["text2"], bg=C["surface"], relief="flat",
                              anchor="w", padx=14, pady=6, cursor="hand2",
                              activebackground=C["surface2"],
                              activeforeground=C["text"],
                              command=lambda p=path: self._go(p))
                b.pack(fill="x")
        tk.Frame(sb, bg=C["border"], height=1).pack(fill="x", padx=8, pady=8)
        tk.Label(sb, text="FORMATS", font=("Courier New",7,"bold"),
                 fg=C["muted"], bg=C["surface"]).pack(anchor="w", padx=12)
        tk.Label(sb, text="PDF  DOCX  DOC\nEPUB HTML  RTF\nODT  TXT   MD  CSV",
                 font=("Courier New",8), fg=C["muted"], bg=C["surface"],
                 justify="left").pack(anchor="w", padx=14, pady=6)

        # File list
        lf = tk.Frame(body, bg=C["bg"])
        lf.grid(row=0, column=1, sticky="nsew")
        lf.rowconfigure(1, weight=1)
        lf.columnconfigure(0, weight=1)

        # Column header
        hdr = tk.Frame(lf, bg=C["surface2"])
        hdr.grid(row=0, column=0, columnspan=2, sticky="ew")
        tk.Label(hdr, text="  Name", font=("Courier New",8,"bold"),
                 fg=C["text2"], bg=C["surface2"], anchor="w",
                 padx=8, pady=6, width=50).pack(side="left")
        tk.Label(hdr, text="Type", font=("Courier New",8,"bold"),
                 fg=C["text2"], bg=C["surface2"], anchor="w",
                 padx=8, pady=6, width=10).pack(side="left")
        tk.Label(hdr, text="Size", font=("Courier New",8,"bold"),
                 fg=C["text2"], bg=C["surface2"], anchor="e",
                 padx=8, pady=6, width=10).pack(side="right")

        # Canvas + scrollbar for custom rows
        self._canvas = tk.Canvas(lf, bg=C["surface"], highlightthickness=0)
        self._canvas.grid(row=1, column=0, sticky="nsew")
        vsc = tk.Scrollbar(lf, orient="vertical", command=self._canvas.yview,
                           bg=C["surface2"], troughcolor=C["bg"], width=10, relief="flat")
        vsc.grid(row=1, column=1, sticky="ns")
        self._canvas.configure(yscrollcommand=vsc.set)
        self._rows_frame = tk.Frame(self._canvas, bg=C["surface"])
        self._canvas_window = self._canvas.create_window((0,0), window=self._rows_frame, anchor="nw")
        self._rows_frame.bind("<Configure>",
            lambda e: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>",
            lambda e: self._canvas.itemconfig(self._canvas_window, width=e.width))
        # Safe scrolling — use local binds only, check widget alive before scrolling
        def _safe_scroll(delta):
            try:
                if self._canvas.winfo_exists():
                    self._canvas.yview_scroll(delta, "units")
            except tk.TclError:
                pass

        def _on_scroll(e):
            if e.num == 4 or (hasattr(e, "delta") and e.delta > 0):
                _safe_scroll(-1)
            else:
                _safe_scroll(1)

        # Bind to canvas and rows frame only (not bind_all)
        for w in (self._canvas, self._rows_frame):
            w.bind("<MouseWheel>", _on_scroll)
            w.bind("<Button-4>",   _on_scroll)
            w.bind("<Button-5>",   _on_scroll)

        # Bottom bar
        bot = tk.Frame(self.win, bg=C["surface"],
                       highlightthickness=1, highlightbackground=C["border"], pady=10)
        bot.pack(fill="x", side="bottom")
        tk.Label(bot, text="File:", font=("Courier New",9,"bold"),
                 fg=C["text2"], bg=C["surface"]).pack(side="left", padx=(16,6))
        self._fname_var = tk.StringVar()
        self._fname_entry = tk.Entry(bot, textvariable=self._fname_var,
                                      bg=C["surface2"], fg=C["text"],
                                      insertbackground=C["cursor"],
                                      relief="flat", font=("Courier New",10),
                                      width=36, bd=4,
                                      highlightthickness=1,
                                      highlightbackground=C["border"])
        self._fname_entry.pack(side="left", padx=(0,10), ipady=3)
        self._fname_entry.bind("<Return>", lambda _: self._open_selected())

        tk.Label(bot, text="Filter:", font=("Courier New",9),
                 fg=C["text2"], bg=C["surface"]).pack(side="left", padx=(8,4))
        self._filter_var = tk.StringVar(value="All supported")
        fc = ttk.Combobox(bot, textvariable=self._filter_var, state="readonly",
                          font=("Courier New",8), width=18,
                          values=["All supported","PDF","Word","EPUB","HTML","Text","All files"])
        fc.pack(side="left", padx=(0,14))
        fc.bind("<<ComboboxSelected>>", lambda _: self._go(self._cur))

        def _cancel(): self.result = None; self.win.destroy()
        tk.Button(bot, text=" Cancel ",
                  font=("Courier New",9,"bold"),
                  bg=C["surface2"], fg=C["text2"], relief="flat",
                  padx=10, pady=5,
                  activebackground=C["border"],
                  command=_cancel).pack(side="right", padx=(4,16))
        self._open_btn = tk.Button(bot, text=" Open ",
                                    font=("Courier New",9,"bold"),
                                    bg=C["accent"], fg="white", relief="flat",
                                    padx=10, pady=5, state="disabled",
                                    activebackground=C["speak_hover"],
                                    activeforeground="white",
                                    command=self._open_selected)
        self._open_btn.pack(side="right", padx=4)

    def _go(self, path: Path):
        if not path.is_dir():
            if path.is_file(): self._select_file(path); return
            return
        self._cur = path.resolve()
        self._path_var.set(str(self._cur))
        self._fname_var.set("")
        self._open_btn.configure(state="disabled")

        # Clear rows
        for w in self._rows_frame.winfo_children(): w.destroy()
        self._items.clear()

        filt    = self._filter_var.get()
        ok_exts = self._filter_exts(filt)
        entries = []
        try:
            for e in sorted(self._cur.iterdir()):
                if e.name.startswith("."): continue
                entries.append(e)
        except PermissionError: return

        dirs  = sorted([e for e in entries if e.is_dir()],  key=lambda x: x.name.lower())
        files = sorted([e for e in entries if e.is_file()], key=lambda x: x.name.lower())

        # Parent
        if self._cur != self._cur.parent:
            self._add_row("  ▲", "../  (parent directory)", "", "", self._cur.parent, True, 0)

        for i, d in enumerate(dirs, 1):
            self._add_row("  ▶", d.name + "/", "folder", "", d, True, i)

        fi = len(dirs)+1
        for f in files:
            ext = f.suffix.lower()
            if ok_exts and ext not in ok_exts: continue
            icon = self.EXT_ICONS.get(ext, "  ·")
            try:    sz = self._fmt_size(f.stat().st_size)
            except: sz = "?"
            self._add_row(icon, f.name, ext.lstrip(".").upper(), sz, f, False, fi)
            fi += 1

        self._canvas.yview_moveto(0)

    def _add_row(self, icon, name, ftype, size, path, is_dir, idx):
        bg = C["surface"] if idx % 2 == 0 else C["surface2"]
        row = tk.Frame(self._rows_frame, bg=bg, cursor="hand2")
        row.pack(fill="x")
        tk.Label(row, text=icon,   font=("Courier New",10), fg=C["accent2"],
                 bg=bg, width=3,  anchor="center", padx=4, pady=5).pack(side="left")
        tk.Label(row, text=name,   font=("Courier New",10), fg=C["text"],
                 bg=bg, anchor="w", padx=4, pady=5).pack(side="left", fill="x", expand=True)
        tk.Label(row, text=ftype,  font=("Courier New",8),  fg=C["muted"],
                 bg=bg, width=8,  anchor="w").pack(side="left")
        tk.Label(row, text=size,   font=("Courier New",8),  fg=C["text2"],
                 bg=bg, width=10, anchor="e", padx=8).pack(side="right")

        i = len(self._items)
        self._items.append((path, is_dir))

        def _enter(e, r=row, b=bg):
            for w in r.winfo_children(): w.configure(bg=C["accent_dim"])
            r.configure(bg=C["accent_dim"])
        def _leave(e, r=row, b=bg):
            for w in r.winfo_children(): w.configure(bg=b)
            r.configure(bg=b)
        def _click(e, idx=i):
            p, isd = self._items[idx]
            self._fname_var.set("" if isd else p.name)
            self._open_btn.configure(state="disabled" if isd else "normal")
        def _dbl(e, idx=i):
            p, isd = self._items[idx]
            if isd: self._go(p)
            else:   self._select_file(p)

        for w in [row] + row.winfo_children():
            w.bind("<Enter>",          _enter)
            w.bind("<Leave>",          _leave)
            w.bind("<Button-1>",       _click)
            w.bind("<Double-Button-1>",_dbl)

    def _filter_exts(self, filt):
        M = {"All supported": file_extractor.SUPPORTED_EXTENSIONS,
             "PDF":[".pdf"], "Word":[".docx",".doc"], "EPUB":[".epub"],
             "HTML":[".html",".htm"], "Text":[".txt",".md"], "All files": None}
        return M.get(filt, file_extractor.SUPPORTED_EXTENSIONS)

    def _fmt_size(self, sz):
        if sz < 1024:    return f"{sz} B"
        if sz < 1024**2: return f"{sz//1024} KB"
        return f"{sz//1024**2} MB"

    def _select_file(self, path: Path):
        self.result = str(path); self.win.destroy()

    def _open_selected(self):
        fn = self._fname_var.get().strip()
        if fn:
            full = self._cur / fn
            if full.is_file(): self._select_file(full)



# ══════════════════════════════════════════════════════════════════════════════
#  CUSTOM SAVE DIALOG
# ══════════════════════════════════════════════════════════════════════════════
class TTSSaveDialog:
    """Themed save dialog matching the Load Document dialog."""
    BOOKMARKS = [
        ("⌂  Home",       Path.home()),
        ("⬇  Downloads",  Path.home()/"Downloads"),
        ("⬡  Documents",  Path.home()/"Documents"),
        ("⬡  Desktop",    Path.home()/"Desktop"),
        ("⬡  Music",      Path.home()/"Music"),
    ]

    def __init__(self, parent, title="Save File", default_ext=".wav",
                 filetypes=None, default_name="output"):
        self.result      = None
        self._cur        = Path.home() / "Downloads"
        self._default_ext= default_ext
        self._filetypes  = filetypes or [("WAV Audio", ".wav")]

        self.win = tk.Toplevel(parent)
        self.win.title(title)
        self.win.geometry("880x520")
        self.win.configure(bg=C["bg"])
        self.win.resizable(True, True)
        self.win.transient(parent)
        self._items = []
        self._build(default_name)
        self._go(self._cur)
        self.win.update()
        self.win.grab_set()
        self.win.focus_force()
        self.win.wait_window()

    def _build(self, default_name):
        # Header
        top = tk.Frame(self.win, bg=C["header_bg"], pady=10)
        top.pack(fill="x")
        tk.Label(top, text=self.win.title(),
                 font=("Courier New",11,"bold"),
                 fg=C["accent2"], bg=C["header_bg"]).pack(side="left", padx=16)
        pf = tk.Frame(top, bg=C["surface2"],
                      highlightthickness=1, highlightbackground=C["border"])
        pf.pack(side="left", fill="x", expand=True, padx=10, ipady=3)
        self._path_var = tk.StringVar(value=str(self._cur))
        pe = tk.Entry(pf, textvariable=self._path_var,
                      bg=C["surface2"], fg=C["text"],
                      insertbackground=C["cursor"],
                      relief="flat", font=("Courier New",9), bd=4)
        pe.pack(fill="x")
        pe.bind("<Return>", lambda _: self._go(Path(self._path_var.get())))
        tk.Button(top, text=" Go ", font=("Courier New",8,"bold"),
                  bg=C["accent"], fg="white", relief="flat",
                  command=lambda: self._go(Path(self._path_var.get())),
                  activebackground=C["speak_hover"],
                  activeforeground="white").pack(side="left", padx=(0,14), ipady=4)

        # Body
        body = tk.Frame(self.win, bg=C["bg"])
        body.pack(fill="both", expand=True)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # Sidebar
        sb = tk.Frame(body, bg=C["surface"], width=165,
                      highlightthickness=1, highlightbackground=C["border"])
        sb.grid(row=0, column=0, sticky="nsew")
        sb.pack_propagate(False)
        tk.Label(sb, text="SAVE TO", font=("Courier New",7,"bold"),
                 fg=C["accent2"], bg=C["surface"], pady=8).pack(fill="x", padx=12)
        tk.Frame(sb, bg=C["border"], height=1).pack(fill="x", padx=8)
        for label, path in self.BOOKMARKS:
            if path.exists():
                b = tk.Button(sb, text=label, font=("Courier New",9),
                              fg=C["text2"], bg=C["surface"], relief="flat",
                              anchor="w", padx=14, pady=6, cursor="hand2",
                              activebackground=C["surface2"],
                              activeforeground=C["text"],
                              command=lambda p=path: self._go(p))
                b.pack(fill="x")

        # File list
        lf = tk.Frame(body, bg=C["bg"])
        lf.grid(row=0, column=1, sticky="nsew")
        lf.rowconfigure(1, weight=1)
        lf.columnconfigure(0, weight=1)

        hdr = tk.Frame(lf, bg=C["surface2"])
        hdr.grid(row=0, column=0, columnspan=2, sticky="ew")
        tk.Label(hdr, text="  Name", font=("Courier New",8,"bold"),
                 fg=C["text2"], bg=C["surface2"], anchor="w",
                 padx=8, pady=6, width=50).pack(side="left")
        tk.Label(hdr, text="Size", font=("Courier New",8,"bold"),
                 fg=C["text2"], bg=C["surface2"], anchor="e",
                 padx=8, pady=6, width=10).pack(side="right")

        self._lb = tk.Listbox(lf,
                               bg=C["surface"], fg=C["text"],
                               selectbackground=C["accent"],
                               selectforeground="white",
                               activestyle="none",
                               font=("Courier New",10),
                               relief="flat", bd=0,
                               highlightthickness=0)
        self._lb.grid(row=1, column=0, sticky="nsew")
        vsc = tk.Scrollbar(lf, orient="vertical", command=self._lb.yview,
                           bg=C["surface2"], troughcolor=C["bg"], width=10, relief="flat")
        vsc.grid(row=1, column=1, sticky="ns")
        self._lb.configure(yscrollcommand=vsc.set)
        self._lb.bind("<Double-Button-1>", self._on_dbl)
        self._lb.bind("<<ListboxSelect>>", self._on_select)

        # Bottom bar
        bot = tk.Frame(self.win, bg=C["surface"],
                       highlightthickness=1, highlightbackground=C["border"], pady=10)
        bot.pack(fill="x", side="bottom")

        tk.Label(bot, text="File name:", font=("Courier New",9,"bold"),
                 fg=C["text2"], bg=C["surface"]).pack(side="left", padx=(16,6))
        self._fname_var = tk.StringVar(value=default_name + self._default_ext)
        fname_e = tk.Entry(bot, textvariable=self._fname_var,
                           bg=C["surface2"], fg=C["text"],
                           insertbackground=C["cursor"],
                           relief="flat", font=("Courier New",10),
                           width=30, bd=4,
                           highlightthickness=1,
                           highlightbackground=C["border"])
        fname_e.pack(side="left", padx=(0,10), ipady=3)
        fname_e.bind("<Return>", lambda _: self._save())

        # Format selector
        tk.Label(bot, text="Format:", font=("Courier New",9),
                 fg=C["text2"], bg=C["surface"]).pack(side="left", padx=(8,4))
        self._fmt_var = tk.StringVar(value=self._filetypes[0][0])
        fmt_cb = ttk.Combobox(bot, textvariable=self._fmt_var,
                              state="readonly", font=("Courier New",8), width=14,
                              values=[ft[0] for ft in self._filetypes])
        fmt_cb.pack(side="left", padx=(0,14))
        fmt_cb.bind("<<ComboboxSelected>>", self._on_fmt_change)

        def _cancel(): self.result = None; self.win.destroy()
        tk.Button(bot, text="  Cancel  ",
                  font=("Courier New",9,"bold"),
                  bg=C["surface2"], fg=C["text2"], relief="flat",
                  padx=10, pady=5, activebackground=C["border"],
                  command=_cancel).pack(side="right", padx=(4,16))
        tk.Button(bot, text="  Save  ",
                  font=("Courier New",9,"bold"),
                  bg=C["speak_bg"], fg="white", relief="flat",
                  padx=10, pady=5,
                  activebackground=C["speak_hover"],
                  activeforeground="white",
                  command=self._save).pack(side="right", padx=4)

    def _go(self, path: Path):
        if not path.is_dir(): return
        self._cur = path.resolve()
        self._path_var.set(str(self._cur))
        self._lb.delete(0, "end")
        self._items.clear()

        try:
            entries = sorted(self._cur.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        except PermissionError:
            return

        if self._cur != self._cur.parent:
            self._lb.insert("end", "  ▲  ../  (parent directory)")
            self._items.append((self._cur.parent, True))

        for e in entries:
            if e.name.startswith("."): continue
            if e.is_dir():
                self._lb.insert("end", f"  ▶  {e.name}/")
                self._items.append((e, True))
            else:
                # Only show audio files + directories
                ext = e.suffix.lower()
                if ext in (".wav", ".mp3", ".flac", ".ogg"):
                    try:    sz = self._fmt_size(e.stat().st_size)
                    except: sz = "?"
                    self._lb.insert("end", f"  ♪  {e.name}   ({sz})")
                    self._items.append((e, False))

        for i in range(0, self._lb.size(), 2):
            self._lb.itemconfig(i, bg=C["surface"])
        for i in range(1, self._lb.size(), 2):
            self._lb.itemconfig(i, bg=C["surface2"])

    def _fmt_size(self, sz):
        if sz < 1024:    return f"{sz} B"
        if sz < 1024**2: return f"{sz//1024} KB"
        return f"{sz//1024**2} MB"

    def _on_select(self, _=None):
        sel = self._lb.curselection()
        if not sel: return
        path, is_dir = self._items[sel[0]]
        if not is_dir:
            self._fname_var.set(path.name)

    def _on_dbl(self, _=None):
        sel = self._lb.curselection()
        if not sel: return
        path, is_dir = self._items[sel[0]]
        if is_dir:  self._go(path)
        else:       self._fname_var.set(path.name)

    def _on_fmt_change(self, _=None):
        # Update filename extension to match selected format
        fmt_name = self._fmt_var.get()
        for name, ext in self._filetypes:
            if name == fmt_name:
                fn = self._fname_var.get()
                stem = Path(fn).stem if fn else "output"
                self._fname_var.set(stem + ext)
                self._default_ext = ext
                break

    def _save(self):
        fn = self._fname_var.get().strip()
        if not fn: return
        # Ensure correct extension
        if not any(fn.lower().endswith(ext) for _, ext in self._filetypes):
            fn += self._default_ext
        self.result = str(self._cur / fn)
        self.win.destroy()


# ══════════════════════════════════════════════════════════════════════════════
#  THEME PICKER DIALOG
# ══════════════════════════════════════════════════════════════════════════════
class ThemePickerDialog:
    """Reliable theme picker - simple buttons, no complex canvas nesting."""
    def __init__(self, parent, current_theme, on_select):
        self._on_select = on_select
        self._current   = current_theme

        self.win = tk.Toplevel(parent)
        self.win.title("Choose Theme")
        self.win.geometry("780x420")
        self.win.configure(bg=C["bg"])
        self.win.resizable(False, False)
        self.win.transient(parent)
        self._build()
        self.win.update()
        self.win.grab_set()
        self.win.focus_force()

    def _build(self):
        # ── Header ─────────────────────────────────────────────────────────
        hdr = tk.Frame(self.win, bg=C["header_bg"])
        hdr.pack(fill="x", ipady=10)
        tk.Label(hdr, text="◑  Choose Theme",
                 font=("Courier New", 13, "bold"),
                 fg=C["accent2"], bg=C["header_bg"],
                 padx=20, pady=8).pack(side="left")
        tk.Label(hdr, text="Click any swatch to apply instantly",
                 font=("Courier New", 9),
                 fg=C["muted"], bg=C["header_bg"]).pack(side="left")
        tk.Frame(self.win, bg=C["border"], height=1).pack(fill="x")

        # ── Grid of theme swatches ──────────────────────────────────────────
        grid_frame = tk.Frame(self.win, bg=C["bg"])
        grid_frame.pack(fill="both", expand=True, padx=20, pady=16)

        themes = list(THEMES.items())
        cols   = 5
        for idx, (key, pal) in enumerate(themes):
            row = idx // cols
            col = idx % cols
            self._swatch(grid_frame, key, pal, row, col)

        for c in range(cols):
            grid_frame.columnconfigure(c, weight=1)

        # ── Footer ─────────────────────────────────────────────────────────
        foot = tk.Frame(self.win, bg=C["surface2"])
        foot.pack(fill="x", side="bottom", ipady=8)
        tk.Button(foot, text="  Cancel  ",
                  font=("Courier New", 9, "bold"),
                  fg=C["text2"], bg=C["surface"],
                  relief="flat", padx=12, pady=5,
                  activebackground=C["border"],
                  command=self.win.destroy).pack(side="right", padx=16)

    def _swatch(self, parent, key, pal, row, col):
        """Each swatch is a single Frame with a Canvas preview + label - fully self-contained."""
        accent   = pal["accent"]
        accent2  = pal["accent2"]
        sel_bg   = pal["surface"]
        outline  = "#ffd700" if key == self._current else pal["border2"]

        # Outer container
        outer = tk.Frame(parent, bg=sel_bg,
                         highlightthickness=2,
                         highlightbackground=outline,
                         cursor="hand2")
        outer.grid(row=row, column=col, padx=7, pady=7, sticky="nsew")

        # Canvas preview (drawn once, immediately)
        W, H = 136, 70
        cv = tk.Canvas(outer, width=W, height=H,
                       bg=pal["bg"],
                       highlightthickness=0)
        cv.pack(padx=0, pady=0)

        # Header bar
        cv.create_rectangle(0,   0,   W,   16,  fill=pal["header_bg"], outline="")
        # Accent pill buttons
        cv.create_rectangle(4,   3,   46,  12,  fill=accent,           outline="")
        cv.create_rectangle(50,  3,   74,  12,  fill=pal["surface"],   outline=pal["border"])
        cv.create_rectangle(78,  3,  102,  12,  fill=pal["surface"],   outline=pal["border"])
        # Textarea area
        cv.create_rectangle(2,   18, 100,  68,  fill=pal["surface"],   outline=pal["border"])
        cv.create_rectangle(5,   23,  75,  27,  fill=pal["text2"],     outline="")
        cv.create_rectangle(5,   31,  55,  34,  fill=pal["muted"],     outline="")
        cv.create_rectangle(5,   38,  65,  41,  fill=pal["muted"],     outline="")
        # Right panel
        cv.create_rectangle(103, 18, W-2,  68,  fill=pal["surface2"],  outline=pal["border"])
        cv.create_rectangle(106, 22, W-5,  31,  fill=accent,           outline="")
        cv.create_rectangle(106, 34, W-5,  41,  fill=pal["stop_bg"],   outline="")
        # Bottom accent stripe
        cv.create_rectangle(0,   66,  W,   70,  fill=accent,           outline="")

        # Label beneath canvas
        lbl_bg = tk.Frame(outer, bg=sel_bg)
        lbl_bg.pack(fill="x")

        # Colour dot
        dot_cv = tk.Canvas(lbl_bg, width=10, height=10,
                           bg=sel_bg, highlightthickness=0)
        dot_cv.pack(side="left", padx=(7, 3), pady=4)
        dot_cv.create_oval(1, 1, 9, 9, fill=accent2, outline="")

        name_lbl = tk.Label(lbl_bg, text=pal["label"],
                            font=("Courier New", 8, "bold"),
                            fg=accent2, bg=sel_bg, anchor="w")
        name_lbl.pack(side="left")

        if key == self._current:
            tk.Label(lbl_bg, text="✓",
                     font=("Courier New", 9, "bold"),
                     fg="#ffd700", bg=sel_bg).pack(side="right", padx=5)

        # Bind ALL widgets – key captured as default arg to avoid closure bug
        def pick(e=None, k=key):
            self._on_select(k)
            self.win.destroy()

        def hover_in(e=None, o=outer, a=accent):
            o.configure(highlightbackground=a)

        def hover_out(e=None, o=outer, b=outline):
            o.configure(highlightbackground=b)

        for w in (outer, cv, lbl_bg, dot_cv, name_lbl):
            w.bind("<Button-1>", pick)
            w.bind("<Enter>",    hover_in)
            w.bind("<Leave>",    hover_out)


# ══════════════════════════════════════════════════════════════════════════════
#  CUSTOM WIDGETS
# ══════════════════════════════════════════════════════════════════════════════
class GlowButton(tk.Frame):
    def __init__(self, parent, text, command=None, fg="white",
                 normal_bg=None, hover_bg=None, font=FONT_BTN, **kw):
        nbg = normal_bg or C["nav_btn"]
        hbg = hover_bg  or C["nav_hover"]
        super().__init__(parent, bg=nbg, cursor="hand2",
                         highlightthickness=1, highlightbackground=C["border2"], **kw)
        self._nbg=nbg; self._hbg=hbg; self._cmd=command
        self._lbl = tk.Label(self, text=text, fg=fg, bg=nbg, font=font,
                             padx=12, pady=6, cursor="hand2")
        self._lbl.pack(fill="both", expand=True)
        for w in (self, self._lbl):
            w.bind("<Enter>",    self._enter)
            w.bind("<Leave>",    self._leave)
            w.bind("<Button-1>", self._click)

    def _enter(self,_=None): self.configure(bg=self._hbg); self._lbl.configure(bg=self._hbg)
    def _leave(self,_=None): self.configure(bg=self._nbg); self._lbl.configure(bg=self._nbg)
    def _click(self,_=None):
        if self._cmd: self._cmd()
    def set_text(self, t):   self._lbl.configure(text=t)
    def set_colors(self, n, h=None):
        self._nbg=n; self._hbg=h or n
        self.configure(bg=n); self._lbl.configure(bg=n)

class NumericControl(tk.Frame):
    def __init__(self, parent, label, var, mn, mx, step, fmt="{:.1f}", **kw):
        super().__init__(parent, bg=C["surface"], **kw)
        self._var=var; self._mn=mn; self._mx=mx; self._step=step; self._fmt=fmt
        self._dvar = tk.StringVar(value=fmt.format(var.get()))
        tk.Label(self, text=label, font=FONT_LABEL, fg=C["text2"], bg=C["surface"],
                 width=9, anchor="w").pack(side="left")
        tk.Button(self, text="−", font=("Courier New",10,"bold"), fg=C["accent2"],
                  bg=C["surface2"], relief="flat", padx=6, pady=1, cursor="hand2",
                  command=self._dec, highlightthickness=0).pack(side="left")
        tk.Label(self, textvariable=self._dvar, font=("Courier New",10,"bold"),
                 fg=C["accent2"], bg=C["surface"], width=7, anchor="center").pack(side="left")
        tk.Button(self, text="+", font=("Courier New",10,"bold"), fg=C["accent2"],
                  bg=C["surface2"], relief="flat", padx=6, pady=1, cursor="hand2",
                  command=self._inc, highlightthickness=0).pack(side="left")
        var.trace_add("write", lambda *_: self._refresh())

    def _refresh(self):
        try: self._dvar.set(self._fmt.format(self._var.get()))
        except Exception: pass
    def _inc(self): self._var.set(min(self._mx, round(self._var.get()+self._step,4)))
    def _dec(self): self._var.set(max(self._mn, round(self._var.get()-self._step,4)))

class SectionHeader(tk.Frame):
    def __init__(self, parent, text, icon="◆", **kw):
        super().__init__(parent, bg=C["surface"], **kw)
        row = tk.Frame(self, bg=C["surface"])
        row.pack(fill="x", pady=(10,4))
        tk.Label(row, text=f"{icon} {text}", font=FONT_LABEL,
                 fg=C["accent2"], bg=C["surface"]).pack(side="left", padx=12)
        tk.Frame(self, bg=C["border"], height=1).pack(fill="x", padx=12)


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ══════════════════════════════════════════════════════════════════════════════
class TTSVoicesApp:
    def __init__(self):
        self.cfg          = load_config()
        self._all_voices  = []
        self._stop_flag   = threading.Event()
        self._is_speaking = False
        self._is_exporting = False   # blocks speak during export and vice versa
        self._wav_buffer          = []
        self._current_file         = ""    # path of currently loaded file
        self._save_point_mgr       = SavePointManager()
        self._resume_from          = 0     # chunk index to resume from
        self._stopped_at_chunk     = 0
        self._fallback_warned      = False
        self._audio_start_time     = 0.0
        self._last_progress_update = 0.0   # for debounced progress bar
        # Real-time highlight sync state
        self._highlight_active      = False
        self._highlight_enabled     = True   # user can toggle on/off
        self._chunk_highlight_data  = {}
        self._current_chunk_index   = 0
        self._theme_key   = self.cfg.get("theme","dark")

        C.update(THEMES.get(self._theme_key, THEMES["dark"]))

        # ── Provider selection at startup ─────────────────────────────────────
        saved_prov = self.cfg.get("provider", "CPU")
        avail      = voices.get_available_providers()

        def _best_gpu_provider():
            if "CUDAExecutionProvider"     in avail: return "CUDAExecutionProvider"
            if "ROCMExecutionProvider"     in avail: return "ROCMExecutionProvider"
            if "TensorrtExecutionProvider" in avail: return "TensorrtExecutionProvider"
            if "OpenVINOExecutionProvider" in avail: return "OpenVINOExecutionProvider"
            if "DmlExecutionProvider"      in avail: return "DmlExecutionProvider"
            return None

        best_gpu = _best_gpu_provider()

        if saved_prov == "CPU":
            voices.set_provider("CPUExecutionProvider")
        elif saved_prov in ("GPU", "CUDA", "CUDA (NVIDIA)") and "CUDAExecutionProvider" in avail:
            voices.set_provider("CUDAExecutionProvider")
        elif saved_prov in ("ROCm (AMD)",) and "ROCMExecutionProvider" in avail:
            voices.set_provider("ROCMExecutionProvider")
        elif saved_prov in ("OpenVINO", "OpenVINO (Intel iGPU)") and "OpenVINOExecutionProvider" in avail:
            voices.set_provider("OpenVINOExecutionProvider")
        elif best_gpu:
            voices.set_provider(best_gpu)
        else:
            voices.set_provider("CPUExecutionProvider")

        self.root = tk.Tk()
        self.root.title(f"TTS Voices {__version__}")
        self.root.geometry("1100x680")
        self.root.minsize(860,560)
        self.root.configure(bg=C["bg"])
        # Set WM_CLASS so all windows group under one taskbar entry on X11
        try:
            self.root.tk.call("tk", "appname", "ttsvoices")
            self.root.wm_iconname("TTS Voices")
        except Exception:
            pass

        self.speed_var    = tk.DoubleVar(value=self.cfg.get("speed",1.3))
        self.pitch_var    = tk.DoubleVar(value=self.cfg.get("pitch",1.0))
        # Volume stored as 0-100 (percent), displayed as 0-100
        raw_vol = self.cfg.get("volume", 63)
        # Migrate old 0-32767 scale to 0-100
        if raw_vol > 100:
            raw_vol = max(1, int(raw_vol / 327.67))
        self.volume_var   = tk.IntVar(value=raw_vol)
        self.voice_var    = tk.StringVar()
        self.status_var   = tk.StringVar(value="READY")
        self.progress_var = tk.DoubleVar(value=0.0)

        self._style_ttk()
        self._build_ui()
        self._load_voices()
        self._refresh_engine_status()
        self._update_gpu_btn()

        for v in (self.speed_var, self.pitch_var, self.volume_var):
            v.trace_add("write", self._on_cfg_change)
        # Apply initial volume to audio system
        self.volume_var.trace_add("write", self._apply_volume)
        self.root.after(100, self._apply_volume)  # Apply on startup

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        # Wire highlight sync callbacks — MUST be called after root exists
        self._setup_audio_callbacks()
        bug_tracker.info(f"TTS Voices 2.0 started  theme={self._theme_key}  provider={voices.get_current_provider()}")



    def _style_ttk(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("TProgressbar", troughcolor=C["surface2"], background=C["accent"],
                    bordercolor=C["border"], lightcolor=C["accent"], darkcolor=C["accent"])
        s.configure("TCombobox", fieldbackground=C["surface2"], background=C["surface2"],
                    foreground=C["text"], selectbackground=C["accent"],
                    selectforeground="white", bordercolor=C["border"], arrowcolor=C["accent2"])
        s.map("TCombobox", fieldbackground=[("readonly",C["surface2"])])

    # ── Build ──────────────────────────────────────────────────────────────────
    def _build_ui(self):
        self._build_header()
        self._build_progress_bar()
        self._build_body()

    def _build_header(self):
        self._hdr = tk.Frame(self.root, bg=C["header_bg"],
                              highlightthickness=1, highlightbackground=C["border"])
        self._hdr.pack(fill="x")

        logo = tk.Frame(self._hdr, bg=C["header_bg"])
        logo.pack(side="left", padx=16, pady=10)
        tk.Label(logo, text="◈", font=("Courier New",18,"bold"),
                 fg=C["accent"], bg=C["header_bg"]).pack(side="left", padx=(0,8))
        tf = tk.Frame(logo, bg=C["header_bg"])
        tf.pack(side="left")
        tk.Label(tf, text="TTS Voices", font=("Courier New",14,"bold"),
                 fg=C["text"], bg=C["header_bg"]).pack(anchor="w")
        tk.Label(tf, text=f"v{__version__}  ·  OFFLINE TTS", font=("Courier New",7,"bold"),
                 fg=C["accent"], bg=C["header_bg"]).pack(anchor="w")

        nav = tk.Frame(self._hdr, bg=C["header_bg"])
        nav.pack(side="right", padx=12, pady=8)

        self._make_nav_btn(nav, "⚙ Settings",     self._open_settings)
        self._make_nav_btn(nav, "◑ Theme",          self._open_theme_picker)
        self._gpu_btn = self._make_nav_btn(nav, "⚡ CPU", self._toggle_gpu, accent=True)
        self._make_nav_btn(nav, "♪ Voice Library", self._open_voice_library)
        self._make_nav_btn(nav, "⚐ Bug Tracker",   self._open_bug_tracker)

        self._status_pill = tk.Label(nav, textvariable=self.status_var,
                                      font=("Courier New",9,"bold"),
                                      fg=C["success"], bg=C["pill_bg"],
                                      padx=12, pady=4,
                                      highlightthickness=1,
                                      highlightbackground=C["success"])
        self._status_pill.pack(side="left", padx=(6,0))

    def _make_nav_btn(self, parent, text, command, accent=False):
        nbg = C["accent"]     if accent else C["nav_btn"]
        hbg = C["accent_dim"] if accent else C["nav_hover"]
        btn = GlowButton(parent, text=text, command=command,
                         normal_bg=nbg, hover_bg=hbg,
                         fg="white" if accent else C["text"],
                         font=("Courier New",8,"bold"))
        btn._lbl.configure(padx=10, pady=5)
        btn.pack(side="left", padx=2)
        return btn

    def _build_progress_bar(self):
        pbf = tk.Frame(self.root, bg=C["surface2"])
        pbf.pack(fill="x")
        self._pb = ttk.Progressbar(pbf, variable=self.progress_var, maximum=100)
        self._pb.pack(fill="x", side="left", expand=True)
        self._pct_lbl = tk.Label(pbf, text="0%", font=("Courier New",8),
                                  fg=C["text2"], bg=C["surface2"], width=5)
        self._pct_lbl.pack(side="right", padx=6)
        self.progress_var.trace_add("write", lambda *_:
            self._pct_lbl.configure(text=f"{self.progress_var.get():.0f}%"))

    def _build_body(self):
        body = tk.Frame(self.root, bg=C["bg"])
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=1); body.columnconfigure(1, weight=0)
        body.rowconfigure(0, weight=1)
        self._build_left(body)
        self._build_right(body)

    def _build_left(self, parent):
        left = tk.Frame(parent, bg=C["bg"])
        left.grid(row=0, column=0, sticky="nsew", padx=(12,6), pady=10)
        left.rowconfigure(1, weight=1); left.columnconfigure(0, weight=1)

        top_bar = tk.Frame(left, bg=C["bg"])
        top_bar.grid(row=0, column=0, sticky="ew", pady=(0,6))
        self._word_lbl = tk.Label(top_bar, text="0 words · 0 chars",
                                   font=("Courier New",8), fg=C["muted"], bg=C["bg"])
        self._word_lbl.pack(side="left", padx=4)
        bf = tk.Frame(top_bar, bg=C["bg"]); bf.pack(side="right")
        GlowButton(bf, text="✕ Clear", command=self._clear_text,
                   normal_bg=C["surface2"], hover_bg=C["border"],
                   fg=C["text2"], font=("Courier New",8)).pack(side="left", padx=3)
        GlowButton(bf, text="⟳ Reset Point", command=self._reset_bookmark,
                   normal_bg=C["surface2"], hover_bg=C["border"],
                   fg=C["accent2"], font=("Courier New",8)).pack(side="left", padx=3)
        GlowButton(bf, text="⬆ Load File", command=self._load_file,
                   normal_bg=C["surface2"], hover_bg=C["border"],
                   fg=C["text"], font=("Courier New",8)).pack(side="left", padx=3)

        ta_frame = tk.Frame(left, bg=C["border"], pady=1, padx=1)
        ta_frame.grid(row=1, column=0, sticky="nsew")
        ta_frame.rowconfigure(0, weight=1); ta_frame.columnconfigure(0, weight=1)

        self._textarea = tk.Text(ta_frame,
                                  bg=C["textarea_bg"], fg=C["textarea_fg"],
                                  insertbackground=C["cursor"],
                                  selectbackground=C["sel_bg"],
                                  selectforeground=C["text"],
                                  relief="flat", wrap="word",
                                  font=("Courier New",11),
                                  padx=20, pady=18, undo=True)
        self._textarea.grid(row=0, column=0, sticky="nsew")
        scrollbar = tk.Scrollbar(ta_frame, command=self._textarea.yview,
                                  bg=C["scrollbar"], troughcolor=C["bg"],
                                  width=10, relief="flat")
        scrollbar.grid(row=0, column=1, sticky="ns")
        self._textarea.configure(yscrollcommand=scrollbar.set)
        self._set_placeholder()
        # Belt-AND-suspenders: clear placeholder on focus, click, OR first keypress
        self._textarea.bind("<FocusIn>",    self._remove_placeholder)
        self._textarea.bind("<Button-1>",   self._remove_placeholder)
        self._textarea.bind("<Key>",        self._remove_placeholder)
        self._textarea.bind("<FocusOut>",   self._maybe_placeholder)
        self._textarea.bind("<KeyRelease>", self._update_wordcount)
        self._placeholder_active = True
        # Mouse wheel scrolling for the textarea
        def _ta_scroll(e):
            try:
                if not self._textarea.winfo_exists(): return
                if e.num == 4 or (hasattr(e, "delta") and e.delta > 0):
                    self._textarea.yview_scroll(-3, "units")
                else:
                    self._textarea.yview_scroll(3, "units")
            except Exception:
                pass
        self._textarea.bind("<MouseWheel>", _ta_scroll)
        self._textarea.bind("<Button-4>",   _ta_scroll)
        self._textarea.bind("<Button-5>",   _ta_scroll)

    def _build_right(self, parent):
        self._right = tk.Frame(parent, bg=C["surface"],
                                highlightthickness=1, highlightbackground=C["border"],
                                width=260)
        self._right.grid(row=0, column=1, sticky="nsew", padx=(0,12), pady=10)
        self._right.pack_propagate(False)

        SectionHeader(self._right, "VOICE", "◆").pack(fill="x")
        vf = tk.Frame(self._right, bg=C["surface"]); vf.pack(fill="x", padx=12, pady=6)
        self._voice_name_lbl = tk.Label(vf, text="Loading voices...",
                                         font=("Courier New",10,"bold"),
                                         fg=C["text"], bg=C["surface"],
                                         wraplength=200, justify="left")
        self._voice_name_lbl.pack(anchor="w")
        self._voice_engine_lbl = tk.Label(vf, text="",
                                           font=("Courier New",8), fg=C["muted"], bg=C["surface"])
        self._voice_engine_lbl.pack(anchor="w", pady=(2,6))
        self._voice_combo = ttk.Combobox(vf, textvariable=self.voice_var,
                                          state="readonly", font=("Courier New",9), width=26)
        self._voice_combo.pack(fill="x")
        self._voice_combo.bind("<<ComboboxSelected>>", self._on_voice_change)

        SectionHeader(self._right, "CONTROLS", "◆").pack(fill="x", pady=(8,0))
        cf = tk.Frame(self._right, bg=C["surface"]); cf.pack(fill="x", padx=8, pady=6)
        NumericControl(cf,"Speed ×",self.speed_var,0.5,3.0,0.1,"{:.1f}").pack(anchor="w",pady=3)
        NumericControl(cf,"Pitch",  self.pitch_var,0.5,2.0,0.1,"{:.1f}").pack(anchor="w",pady=3)
        NumericControl(cf,"Volume %",self.volume_var,0,100,5,"{:d}").pack(anchor="w",pady=3)

        SectionHeader(self._right, "PLAYBACK", "▶").pack(fill="x", pady=(8,0))
        pf = tk.Frame(self._right, bg=C["surface"]); pf.pack(fill="x", padx=12, pady=8)
        self._speak_btn = GlowButton(pf, text="▶  SPEAK", command=self._on_speak,
                                      normal_bg=C["speak_bg"], hover_bg=C["speak_hover"],
                                      fg="white", font=("Courier New",11,"bold"))
        self._speak_btn.pack(fill="x", pady=(0,6))
        self._speak_btn._lbl.configure(pady=10)
        self._stop_btn = GlowButton(pf, text="■  STOP", command=self._on_stop,
                                     normal_bg=C["stop_bg"], hover_bg=C["stop_hover"],
                                     fg="white", font=("Courier New",10,"bold"))
        self._stop_btn.pack(fill="x")
        self._stop_btn._lbl.configure(pady=7)

        # ── Highlight sync toggle ────────────────────────────────────────
        self._hl_btn = GlowButton(pf, text="◈ Highlight Sync  ON",
                                   command=self._toggle_highlight,
                                   normal_bg=C["surface2"], hover_bg=C["border"],
                                   fg=C["accent2"], font=("Courier New", 7, "bold"))
        self._hl_btn.pack(fill="x", pady=(6,0))
        self._hl_btn._lbl.configure(pady=3)

        SectionHeader(self._right, "EXPORT", "◆").pack(fill="x", pady=(8,0))
        ef = tk.Frame(self._right, bg=C["surface"]); ef.pack(fill="x", padx=12, pady=8)
        er = tk.Frame(ef, bg=C["surface"]); er.pack(fill="x")
        GlowButton(er, text="WAV", command=self._export_wav,
                   normal_bg=C["surface2"], hover_bg=C["border"],
                   fg=C["success"], font=("Courier New",9,"bold")).pack(
            side="left", fill="x", expand=True, padx=(0,4))
        GlowButton(er, text="MP3", command=self._export_mp3,
                   normal_bg=C["surface2"], hover_bg=C["border"],
                   fg=C["accent2"], font=("Courier New",9,"bold")).pack(
            side="left", fill="x", expand=True)
        # Export progress bar + status (hidden until export starts)
        self._export_progress_var = tk.DoubleVar(value=0.0)
        self._export_pb = ttk.Progressbar(ef, variable=self._export_progress_var,
                                           maximum=100)
        self._export_pb.pack(fill="x", pady=(6,0))
        self._export_status_lbl = tk.Label(ef, text="",
                                            font=("Courier New", 7),
                                            fg=C["success"], bg=C["surface"],
                                            anchor="w")
        self._export_status_lbl.pack(fill="x")

        SectionHeader(self._right, "ENGINE STATUS", "◉").pack(fill="x", pady=(4,0))
        self._engine_frame = tk.Frame(self._right, bg=C["surface"])
        self._engine_frame.pack(fill="x", padx=8, pady=4)
        self._engine_labels = {}
        for eng in [voices.ENGINE_KOKORO, voices.ENGINE_ESPEAK]:
            row = tk.Frame(self._engine_frame, bg=C["surface"])
            row.pack(anchor="w", pady=1, fill="x")
            # Use wraplength so long names wrap instead of being clipped
            lbl = tk.Label(row, text=f"· {eng}", font=("Courier New",7),
                           fg=C["muted"], bg=C["surface"],
                           anchor="w", wraplength=230)
            lbl.pack(side="left", fill="x")
            self._engine_labels[eng] = lbl

        tk.Label(self._right, text="v2.0  ·  Apache 2.0",
                 font=("Courier New",7), fg=C["muted"], bg=C["surface"]).pack(side="bottom",pady=8)

    # ── Placeholder ────────────────────────────────────────────────────────────
    # Placeholder text — stored so _get_text can detect stale flag
    _PLACEHOLDER = "Type or paste text here, or use ⬆ Load File to open a document..."

    def _set_placeholder(self):
        self._textarea.delete("1.0", "end")
        self._textarea.insert("1.0",
            f"{self._PLACEHOLDER}\n\n"
            f"Supported formats: {file_extractor.SUPPORTED_DISPLAY}")
        self._textarea.configure(fg=C["muted"])
        self._placeholder_active = True

    def _remove_placeholder(self, _=None):
        """Clear placeholder. Called on FocusIn, Button-1, and first KeyPress."""
        if self._placeholder_active:
            self._textarea.delete("1.0", "end")
            self._textarea.configure(fg=C["textarea_fg"])
            self._placeholder_active = False

    def _maybe_placeholder(self, _=None):
        """Restore placeholder on FocusOut ONLY if textarea is truly empty."""
        raw = self._textarea.get("1.0", "end").strip()
        # Don't wipe real user text — only restore if genuinely empty
        if not raw or raw.startswith(self._PLACEHOLDER[:30]):
            self._set_placeholder()

    def _is_placeholder_content(self) -> bool:
        """True if textarea contains only the placeholder (regardless of flag)."""
        raw = self._textarea.get("1.0", "end").strip()
        return not raw or raw.startswith(self._PLACEHOLDER[:30])

    # ── Voice ──────────────────────────────────────────────────────────────────
    def _load_voices(self):
        self._all_voices = voices.get_all_voices()
        if not self._all_voices: self._all_voices=[("No engines found","","")]
        names=[v[0] for v in self._all_voices]
        self._voice_combo["values"]=names
        idx=min(self.cfg.get("voice_idx",0),len(names)-1)
        self._voice_combo.current(idx); self._update_voice_display()

    def _on_voice_change(self,_=None): self._update_voice_display(); self._save_cfg_now()

    def _update_voice_display(self):
        idx=self._voice_combo.current()
        if 0<=idx<len(self._all_voices):
            display,engine,vname=self._all_voices[idx]
            short=display.split(" · ",1)[-1] if " · " in display else display
            self._voice_name_lbl.configure(text=short)
            self._voice_engine_lbl.configure(text=f"{engine}  ·  Apache 2.0")
        self.cfg["voice_idx"]=idx

    def _refresh_engine_status(self):
        status=voices.get_engine_status()
        for eng,lbl in self._engine_labels.items():
            lbl.configure(text=f"✓ {eng}" if status.get(eng) else f"✗ {eng}",
                           fg=C["success"] if status.get(eng) else C["muted"])

    # ── Text ───────────────────────────────────────────────────────────────────
    def _get_text(self) -> str:
        """
        Get textarea text, sanitized and placeholder-aware.
        Uses content inspection so a stale flag never silences real text.
        """
        raw = self._textarea.get("1.0", "end")

        # Step 1: sanitize control chars (null bytes, etc.) before any check
        clean = "".join(ch for ch in raw if ch >= " " or ch in "\n\t")
        stripped = clean.strip()

        # Step 2: content-first placeholder detection
        if not stripped or stripped.startswith(self._PLACEHOLDER[:30]):
            self._placeholder_active = True   # heal stale flag
            return ""

        # Step 3: heal stale flag if real content is present
        if self._placeholder_active:
            self._placeholder_active = False
            self._textarea.configure(fg=C["textarea_fg"])

        return stripped

    def _update_wordcount(self, _=None):
        text = self._get_text()   # uses content-aware check
        if not text:
            self._word_lbl.configure(text="0 words · 0 chars")
            return
        words = len(text.split())
        chars = len(text)
        self._word_lbl.configure(text=f"{words:,} words · {chars:,} chars")

    def _clear_text(self):
        # If speaking, stop cleanly first so the worker thread finishes
        # before we clear the buffer — prevents the worker iterating a
        # cleared list and exiting without calling _on_speak_complete,
        # which would leave the SPEAK button stuck grey.
        if self._is_speaking:
            self._on_stop()
        self._set_placeholder(); self._update_wordcount()
        self._wav_buffer.clear(); self.progress_var.set(0)

    def _load_file(self):
        dlg=TTSFileDialog(self.root); path=dlg.result
        if not path: return
        # Store path immediately on main thread so resume logic can use it
        self._current_file = path
        self._set_status("Loading...",C["warning"])
        def _do():
            try:
                text=file_extractor.extract_text(path)
                self.root.after(0,lambda: self._insert_file_text(text, path))
            except Exception as e:
                self.root.after(0,lambda err=e: self._dialog("Load Error", f"Could not read:\n{err}", "error"))
                self.root.after(0,lambda: self._set_status("READY",C["success"]))
        threading.Thread(target=_do,daemon=True).start()

    def _insert_file_text(self, text, path=""):
        if not text or not text.strip():
            self._set_status("READY", C["success"])
            self._dialog("Empty File",
                "The file was loaded but no text could be extracted.\n"
                "It may be empty, image-only, or the password may be incorrect.",
                "warn")
            return

        # Guard against binary garbage (e.g. failed decryption returning raw zip bytes)
        first = text.strip()[:4]
        if first.startswith("PK") or "\x00" in text[:100]:
            self._set_status("READY", C["success"])
            self._dialog("Extraction Error",
                "The file appears to contain binary data instead of text.\n\n"
                "If this is a password-protected file, the password may be wrong.\n"
                "Try loading it again and entering the correct password.",
                "error")
            return

        # Update _current_file with the path that was just loaded
        if path:
            self._current_file = path

        self._remove_placeholder()
        self._textarea.delete("1.0", "end")
        self._textarea.insert("1.0", text)
        self._update_wordcount()
        self._set_status("READY", C["success"])
        bug_tracker.info(f"File inserted: {len(text):,} chars  path={self._current_file}")

        # Load persistent save point for this exact file path
        self._save_point_mgr.load_for_file(self._current_file)

        # Check config bookmark first (more recent than SavePointManager)
        saved_file  = self.cfg.get("bookmark_file", "")
        saved_chunk = self.cfg.get("bookmark_chunk", 0)
        if saved_chunk > 0 and saved_file == self._current_file:
            self._show_bookmark_indicator(saved_chunk)
            self._set_status(
                f"📌  Resuming from chunk {saved_chunk} — press Speak",
                C["accent2"])
        elif self._save_point_mgr.has_save_point():
            sc = self._save_point_mgr.get_start_chunk()
            self._set_status(
                f"📌  Resume available from chunk {sc} — press Speak",
                C["accent2"])

    # ── Speech ─────────────────────────────────────────────────────────────────
    def _on_speak(self):
        if self._is_speaking: return
        if self._is_exporting:
            self._dialog("Export in Progress",
                "Please wait for the export to finish before speaking.", "warn")
            return
        text = self._get_text()
        if not text:
            self._dialog("No Text", "Please type or paste some text first,\nor use Load File to open a document.", "warn")
            return
        idx = self._voice_combo.current()
        if idx < 0: return
        _, engine, voice_name = self._all_voices[idx]
        speed = self.speed_var.get()
        pitch = self.pitch_var.get()

        self._is_speaking = True
        self._stop_flag.clear()
        self._wav_buffer.clear()
        self._fallback_warned = False   # reset per-session fallback warning
        self.progress_var.set(0)
        self._set_status("SYNTHESIZING...", C["warning"])
        self._speak_btn.set_colors("#333344", "#333344")

        chunks = voices.chunk_text(text)
        total  = len(chunks)

        # ── Resume from bookmark if same file ────────────────────────────
        saved_file  = self.cfg.get("bookmark_file", "")
        saved_chunk = self.cfg.get("bookmark_chunk", 0)
        current_file = getattr(self, "_current_file", "")
        # Build char-position index for ALL chunks BEFORE slicing
        # (positions are absolute offsets in the full text, needed for highlighting)
        all_positions = []
        search_start  = 0
        for chunk in chunks:
            first_words = " ".join(chunk.split()[:6])
            pos = text.find(first_words, search_start)
            if pos == -1:
                pos = search_start
            all_positions.append(pos)
            search_start = pos + 1

        if saved_chunk > 0 and saved_file == current_file and saved_chunk < total:
            self._resume_from = saved_chunk
            chunks          = chunks[saved_chunk:]
            chunk_positions = all_positions[saved_chunk:]
            self.progress_var.set(saved_chunk / total * 100)
            self._set_status(f"RESUMING from {saved_chunk}/{total}...", C["accent2"])
        else:
            self._resume_from = 0
            chunk_positions   = all_positions

        def _worker():
            """
            Phase 1 (0→100%): Synthesize all chunks, update progress bar.
            Phase 2 (100%):   Play chunks sequentially with word highlighting.
            """
            # ── Phase 1: Synthesize ───────────────────────────────────────
            try:
                for i, chunk in enumerate(chunks):
                    if self._stop_flag.is_set():
                        # Save how many chunks we synthesized so resume
                        # starts from the right place even if stopped in Phase 1
                        self._stopped_at_chunk = self._resume_from + i
                        self.root.after(0, self._on_speak_complete)
                        return
                    try:
                        # Read controls per-chunk so changes take effect immediately
                        cur_speed = self.speed_var.get()
                        cur_pitch = self.pitch_var.get()
                        wav = voices.synthesize(chunk, engine, voice_name, cur_speed, cur_pitch)
                        self._wav_buffer.append(wav)
                        # Warn once per session if Kokoro fell back to espeak
                        if voices.fallback_occurred:
                            self.root.after(0, lambda ci=i:
                                self._set_status(
                                    f"⚠  Chunk {ci+1}: Kokoro failed → espeak fallback  "
                                    f"(try CPU mode or lower speed)",
                                    C["warning"]))
                            if not getattr(self, "_fallback_warned", False):
                                self._fallback_warned = True
                                self.root.after(500, self._show_fallback_warning)
                    except Exception as e:
                        bug_tracker.error(f"Chunk {i} synthesis failed: {e}")
                        self.root.after(0, lambda err=e: self._dialog("TTS Error", f"Synthesis failed:\n{err}", "error"))
                        self.root.after(0, self._on_speak_complete)
                        return
                    pct = (i + 1) / total * 100
                    now = time.monotonic()
                    if now - self._last_progress_update > 0.1:  # max 10 updates/sec
                        self._last_progress_update = now
                        self.root.after(0, lambda p=pct: self.progress_var.set(p))

            except Exception as e:
                bug_tracker.error(f"Synthesis phase failed: {e}")
                self.root.after(0, self._on_speak_complete)
                return

            # ── Phase 2: Play with highlighting ───────────────────────────
            if not self._wav_buffer:
                self.root.after(0, self._on_speak_complete)
                return

            self.root.after(0, lambda: self._set_status("PLAYING  ▶", C["success"]))
            self.root.after(0, self._setup_highlight_tag)

            self._stopped_at_chunk    = 0   # reset before playback
            self._chunk_highlight_data = {}  # clear old timing data

            # Filter out any None entries left by stream-and-discard from a
            # previous session — they crash play_wav with TypeError: NoneType
            # Take a LOCAL snapshot of the buffer before the play loop.
            # This eliminates ALL IndexError / NoneType races:
            # - export thread clearing _wav_buffer mid-iteration → no effect
            # - _wav_buffer[i] = None index-out-of-range → never happens
            # chunk_index maps snapshot position → original chunk index for highlighting
            local_play = [(orig_i, wav)
                          for orig_i, wav in enumerate(self._wav_buffer)
                          if wav is not None]
            # Free the shared buffer now — we have our local copy
            self._wav_buffer.clear()

            for seq_i, (orig_i, wav) in enumerate(local_play):
                if self._stop_flag.is_set():
                    self._stopped_at_chunk = self._resume_from + orig_i
                    break

                self._current_chunk_index = orig_i   # on_start callback reads this

                # Calculate audio duration from WAV header
                try:
                    import wave as _wave, io as _io
                    with _wave.open(_io.BytesIO(wav)) as _wf:
                        wav_dur = _wf.getnframes() / _wf.getframerate()
                except Exception:
                    wav_dur = len(chunks[orig_i].split()) * 0.12

                if self._highlight_enabled and orig_i < len(chunks) and orig_i < len(chunk_positions):
                    self._prepare_highlight_data(
                        chunks[orig_i], chunk_positions[orig_i], wav_dur, text)

                played = audio_handler.play_wav(wav)
                if not played and not self._stop_flag.is_set():
                    bug_tracker.warning(f"play_wav returned False for chunk {orig_i} — skipping")
                # wav local var goes out of scope each iteration → GC frees it

            # Clear highlight when done
            self.root.after(0, self._clear_highlight)
            self.root.after(0, self._on_speak_complete)

        def _worker_safe():
            """Wrap _worker so any unhandled crash still resets UI state."""
            try:
                _worker()
            except Exception as e:
                bug_tracker.error(f"Worker thread crashed: {e}")
                self.root.after(0, self._on_speak_complete)
                self.root.after(0, self._clear_highlight)

        threading.Thread(target=_worker_safe, daemon=True).start()

    def _on_stop(self):
        self._cancel_highlights()   # cancel word highlights immediately
        self._stop_flag.set()
        audio_handler.stop_playback()
        self._on_speak_complete()

    def _on_speak_complete(self):
        self._is_speaking = False
        self._set_status("READY", C["success"])
        self._speak_btn.set_colors(C["speak_bg"], C["speak_hover"])
        if self._stop_flag.is_set():
            self.progress_var.set(0)
            # Save bookmark at chunk where we stopped
            self._save_bookmark(self._stopped_at_chunk)
        else:
            # Finished naturally — clear bookmark and progress bar
            self.progress_var.set(0)
            self._save_bookmark(0)
        self._clear_highlight()

    def _reset_bookmark(self):
        """Reset the saved playback point so next Speak starts from beginning."""
        self._save_bookmark(0)
        self._save_point_mgr.clear_save_point()
        self._set_status("📌  Saved point cleared — will start from beginning", C["text2"])

    def _save_bookmark(self, chunk_idx: int):
        """Persist save point both in config and in SavePointManager (file-hash storage)."""
        self.cfg["bookmark_chunk"] = chunk_idx
        self.cfg["bookmark_file"]  = getattr(self, "_current_file", "")
        save_config(self.cfg)
        # Also persist via SavePointManager for cross-session durability
        self._save_point_mgr.current_file = self._current_file
        self._save_point_mgr.set_save_point(chunk_idx)
        if chunk_idx > 0:
            self._show_bookmark_indicator(chunk_idx)
        else:
            self._hide_bookmark_indicator()

    def _show_bookmark_indicator(self, chunk_idx: int):
        """Show a small bookmark badge near the word count label."""
        try:
            if not hasattr(self, "_bookmark_lbl"):
                return
            self._bookmark_lbl.configure(
                text=f"  📌 Resumed from chunk {chunk_idx}",
                fg=C["accent2"]
            )
        except Exception:
            pass

    def _hide_bookmark_indicator(self):
        try:
            if hasattr(self, "_bookmark_lbl"):
                self._bookmark_lbl.configure(text="")
        except Exception:
            pass

    # ── Text Highlighting ──────────────────────────────────────────────────
    def _setup_highlight_tag(self):
        """Configure the highlight tag: vivid blue with solid background for body."""
        try:
            self._textarea.tag_configure(
                "speaking",
                foreground="#00d4ff",        # neon cyan — matches VOICE/CONTROLS headers
                background="#003344",        # dark navy base
                font=("Courier New", 11, "bold"),
            )
        except Exception:
            pass

    def _highlight_word(self, char_offset: int):
        """Highlight the single word at char_offset in the textarea."""
        try:
            self._textarea.tag_remove("speaking", "1.0", "end")
            idx = f"1.0+{char_offset}c"
            self._textarea.tag_add("speaking", idx, f"{idx} wordend")
            self._textarea.see(idx)
        except Exception:
            pass

    def _highlight_range(self, char_start: int, char_end: int):
        """Legacy: highlight a range. Now unused — kept for compatibility."""
        self._highlight_word(char_start)

    def _estimate_word_durations(self, words: list, total_s: float) -> list:
        """
        Estimate per-word duration with syllable weighting AND punctuation pauses.

        Kokoro TTS adds natural pauses after punctuation. Without accounting for
        these, the highlight timing drifts forward over long texts because all the
        "extra" time from pauses gets distributed across words evenly — making
        each word appear slightly shorter than it really is, so the highlight
        runs ahead of speech.

        Pause weights (relative units added to the word before the pause):
          sentence end (. ! ?)  → +1.5  units  (~300-500ms in natural speech)
          clause break (, ; :)  → +0.6  units  (~100-200ms)
          dash / ellipsis       → +0.4  units
        """
        import re

        def syllables(word):
            w = re.sub(r"[^a-zA-Z]", "", word.lower())
            if not w:
                return 1
            count = len(re.findall(r"[aeiouy]+", w))
            if w.endswith("e") and count > 1:
                count -= 1
            return max(1, count)

        def pause_weight(word):
            """Extra time units for the pause AFTER this word."""
            stripped = word.rstrip()
            if not stripped:
                return 0.0
            last = stripped[-1]
            if last in ".!?":   return 1.5
            if last in ",;:":   return 0.6
            if last in "-—…":   return 0.4
            return 0.0

        # Build weights: syllable count + punctuation pause
        weights = []
        for w in words:
            syl_w = syllables(w)
            pau_w = pause_weight(w)
            weights.append(syl_w + pau_w)

        tot = sum(weights)
        if tot == 0:
            # Fallback: equal distribution
            return [total_s / len(words)] * len(words)

        return [(w / tot) * total_s for w in weights]

    def _setup_audio_callbacks(self):
        """
        Wire audio_handler callbacks for highlight loop timing.

        _on_start fires from the worker thread right after Popen().
        We schedule the highlight loop via root.after(0,...) to switch
        to the main thread. The _LATENCY_COMP in the loop accounts for
        the time between Popen and audio actually reaching the speakers.
        """
        def _on_start():
            # Called from worker thread — must use root.after to touch Tkinter.
            # Capture chunk index immediately (before worker advances it).
            chunk_idx = self._current_chunk_index
            # after(0,...) puts this on the main thread event queue immediately.
            # get_playback_position() uses wall-clock time from Popen, so the
            # loop catches up to real elapsed time on its first iteration.
            self.root.after(0, lambda: self._run_realtime_highlight_loop(chunk_idx))

        def _on_stop():
            # Clear highlight when audio subprocess exits
            self.root.after(0, self._clear_highlight)

        audio_handler.set_callbacks(on_start=_on_start, on_stop=_on_stop)

    def _prepare_highlight_data(self, chunk_text: str, chunk_char_start: int,
                                wav_duration_s: float, full_text: str):
        """
        Prepare word timing data for a chunk. Called synchronously from the
        worker thread BEFORE play_wav() so data is ready when on_start fires.

        Takes full_text as a parameter (the original text variable from _on_speak)
        so this can safely run on the worker thread without touching Tk widgets.
        The highlight loop is started by _setup_audio_callbacks on_start callback.
        """
        words = chunk_text.split()
        if not words or wav_duration_s <= 0:
            return

        # Map each word to its absolute char offset using the cached full_text
        word_offsets = []
        pos = chunk_char_start
        for word in words:
            found = full_text.find(word, pos)
            if found != -1:
                word_offsets.append(found)
                pos = found + len(word)
            else:
                word_offsets.append(pos)

        # Build cumulative timestamp list proportional to syllable count
        durations = self._estimate_word_durations(words, wav_duration_s)
        cumulative_times = []
        elapsed = 0.0
        for dur in durations:
            cumulative_times.append(elapsed)
            elapsed += dur

        # Store data keyed by chunk index — loop reads this when it starts
        chunk_idx = self._current_chunk_index
        self._chunk_highlight_data[chunk_idx] = {
            "offsets":  word_offsets,
            "times":    cumulative_times,
            "duration": wav_duration_s,
        }

    def _run_realtime_highlight_loop(self, chunk_index: int):
        """
        Real-time 20ms polling loop that syncs word highlights to actual audio.
        Runs entirely on the main thread (started via root.after from on_start cb).

        Key fixes vs previous version:
        - Calls _highlight_word() directly — no inner root.after(0,...) double-hop
        - Started from on_start callback so t=0 matches actual Popen time
        - 50ms latency compensation for aplay/paplay buffer startup delay
        - 20ms poll interval (was 30ms) for tighter tracking
        """
        # Latency = time from Popen() to audio reaching speakers.
        # Linux PipeWire/ALSA typical: 120-200ms.
        # User-tunable in Settings so each system can be calibrated.
        # Positive value = delay highlights (speech is ahead)
        # Negative value = advance highlights (highlights are ahead)
        _LATENCY_COMP = self.cfg.get("highlight_offset", 150) / 1000.0

        data = self._chunk_highlight_data.get(chunk_index)
        if not data:
            return

        offsets  = data["offsets"]
        times    = data["times"]
        duration = data["duration"]
        if not offsets or not times:
            return

        last_word_idx = [-1]

        def _update():
            if not self._highlight_active or self._stop_flag.is_set()                     or not self._highlight_enabled:
                return

            raw_elapsed = audio_handler.get_playback_position()
            # Apply latency compensation — how far AHEAD of Popen the
            # audio actually reaches speakers (Linux PipeWire/ALSA buffer)
            elapsed = max(0.0, raw_elapsed - _LATENCY_COMP)

            # Use bisect to find the current word in O(log n)
            # bisect_right(times, elapsed) - 1 gives the last word whose
            # start time is <= elapsed, i.e. the word currently being spoken
            import bisect
            word_idx = max(0, bisect.bisect_right(times, elapsed) - 1)

            # Only update when word actually changes — avoids redundant redraws
            if word_idx != last_word_idx[0] and word_idx < len(offsets):
                last_word_idx[0] = word_idx
                self._highlight_word(offsets[word_idx])

            if raw_elapsed < duration + _LATENCY_COMP and not self._stop_flag.is_set():
                self.root.after(16, _update)   # ~60fps for smoother tracking
            else:
                self._highlight_active = False

        self._highlight_active = True
        self.root.after(0, _update)   # start immediately on main thread

    def _toggle_highlight(self):
        """Toggle word highlight sync on or off."""
        self._highlight_enabled = not self._highlight_enabled
        if self._highlight_enabled:
            self._hl_btn.set_text("◈ Highlight Sync  ON")
            self._hl_btn._lbl.configure(fg=C["accent2"])
        else:
            self._highlight_enabled = False
            self._hl_btn.set_text("◈ Highlight Sync  OFF")
            self._hl_btn._lbl.configure(fg=C["muted"])
            self._clear_highlight()

    def _cancel_highlights(self):
        """Cancel real-time highlight loop and clear all timing data."""
        self._highlight_active = False
        for after_id in getattr(self, "_highlight_after_ids", []):
            try: self.root.after_cancel(after_id)
            except Exception: pass
        self._highlight_after_ids    = []
        self._chunk_highlight_data   = {}

    
    def _clear_highlight(self):
        """Remove all speech highlighting."""
        try:
            self._textarea.tag_remove("speaking", "1.0", "end")
        except Exception:
            pass

    def _show_fallback_warning(self):
        """Non-blocking toast: Kokoro fell back to espeak on a chunk."""
        try:
            toast = tk.Toplevel(self.root)
            toast.overrideredirect(True)
            toast.configure(bg=C["surface"],
                            highlightthickness=2,
                            highlightbackground=C["warning"])
            toast.attributes("-topmost", True)

            tk.Label(toast,
                     text="⚠  Voice quality reduced",
                     font=("Courier New", 9, "bold"),
                     fg=C["warning"], bg=C["surface"],
                     padx=14, pady=6).pack()
            tk.Label(toast,
                     text="Kokoro hit the phoneme limit on a passage.\n"
                          "espeak-ng fallback was used for that chunk.\n"
                          "→ Try: switch to CPU · lower speed · shorter sentences",
                     font=("Courier New", 8),
                     fg=C["text2"], bg=C["surface"],
                     padx=14, pady=(0, 10)).pack()

            self.root.update_idletasks()
            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
            toast.update_idletasks()
            tw = toast.winfo_reqwidth()
            th = toast.winfo_reqheight()
            toast.geometry(f"+{sw - tw - 20}+{sh - th - 60}")

            toast.after(7000, lambda: toast.destroy()
                        if toast.winfo_exists() else None)
        except Exception:
            pass

    def _dialog(self, title: str, message: str, kind: str = "info"):
        """Show a themed dialog matching the app style. kind: info | error | warn"""
        icons  = {"info": "ℹ", "error": "✗", "warn": "⚠"}
        colors = {"info": C["accent2"], "error": C["error"], "warn": C["warning"]}
        icon   = icons.get(kind, "ℹ")
        color  = colors.get(kind, C["accent2"])

        win = tk.Toplevel(self.root)
        win.title(title)
        win.configure(bg=C["bg"])
        win.resizable(False, False)
        win.transient(self.root)

        # Header
        hdr = tk.Frame(win, bg=C["header_bg"])
        hdr.pack(fill="x")
        tk.Label(hdr, text=f"{icon}  {title}",
                 font=("Courier New", 11, "bold"),
                 fg=color, bg=C["header_bg"],
                 padx=20, pady=10).pack(side="left")
        tk.Frame(win, bg=C["border"], height=1).pack(fill="x")

        # Message
        body = tk.Frame(win, bg=C["bg"], padx=28, pady=20)
        body.pack(fill="x")
        tk.Label(body, text=message,
                 font=("Courier New", 10),
                 fg=C["text"], bg=C["bg"],
                 wraplength=380, justify="left").pack(anchor="w")

        tk.Frame(win, bg=C["border"], height=1).pack(fill="x")

        # Button
        foot = tk.Frame(win, bg=C["surface"], pady=10)
        foot.pack(fill="x")
        tk.Button(foot, text="  OK  ",
                  font=("Courier New", 9, "bold"),
                  bg=C["accent"], fg="white",
                  relief="flat", padx=16, pady=6,
                  cursor="hand2",
                  activebackground=C["speak_hover"],
                  activeforeground="white",
                  command=win.destroy).pack(side="right", padx=16)

        win.update_idletasks()
        w = win.winfo_reqwidth()
        h = win.winfo_reqheight()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        win.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        win.grab_set()
        self.root.wait_window(win)

    # ── Export ─────────────────────────────────────────────────────────────────
    def _ensure_wav_buffer(self) -> bool:
        """Return True if wav_buffer has valid (non-None) WAV data.

        Three cases:
        1. Buffer has valid data  -> return True immediately
        2. Buffer is empty        -> synthesize now
        3. Buffer is all-None     -> stream-and-discard already played everything;
                                     must re-synthesize for export
        """
        # Check for valid (non-None) entries — stream-and-discard sets entries to None
        valid = [c for c in self._wav_buffer if c is not None]
        if valid:
            return True

        # Buffer either empty or fully discarded — need to synthesize
        text = self._get_text()
        if not text:
            self._dialog("Nothing to Export",
                         "Please type or load a document first.", "warn")
            return False
        idx = self._voice_combo.current()
        if idx < 0:
            return False
        _, engine, voice_name = self._all_voices[idx]
        speed = self.speed_var.get()
        pitch = self.pitch_var.get()
        chunks = voices.chunk_text(text)
        total  = max(len(chunks), 1)

        # Clear stale None entries before re-filling
        self._wav_buffer.clear()

        self._set_status("SYNTHESIZING...", C["warning"])
        for i, chunk in enumerate(chunks):
            if self._stop_flag.is_set():
                break
            try:
                wav = voices.synthesize(chunk, engine, voice_name, speed, pitch)
                self._wav_buffer.append(wav)
                # Drive export progress bar during synthesis (0-80%)
                pct = (i + 1) / total * 80
                self.root.after(0, lambda p=pct: self._export_progress_var.set(p))
                self.root.after(0, lambda p=pct: self._export_status_lbl.configure(
                    text=f"Synthesizing... {int(p)}%", fg=C["warning"]))
            except Exception as e:
                bug_tracker.error(f"Export synthesis failed chunk {i}: {e}")
                self._dialog("Synthesis Error",
                             f"Failed to synthesize chunk {i+1}:\n{e}", "error")
                self._set_status("READY", C["success"])
                return False
        self._set_status("READY", C["success"])
        return bool(self._wav_buffer)

    def _export_wav(self):
        """Export to WAV. All Tk calls happen on main thread — only I/O in worker."""
        if self._is_speaking:
            self._dialog("Export Blocked",
                "Please press STOP before speaking ends, then export.", "warn")
            return
        if self._is_exporting:
            self._dialog("Already Exporting",
                "An export is already in progress. Please wait.", "warn")
            return
        # ── Pre-validate on main thread before spawning worker ────────────────
        text = self._get_text()
        if not text:
            self._dialog("Nothing to Export",
                "Please type or load a document first.", "warn")
            return
        idx = self._voice_combo.current()
        if idx < 0 or idx >= len(self._all_voices):
            return
        _, engine, voice_name = self._all_voices[idx]
        speed = self.speed_var.get()
        pitch = self.pitch_var.get()

        dlg = TTSSaveDialog(self.root, title="Export as WAV",
                            default_ext=".wav",
                            filetypes=[("WAV Audio", ".wav")],
                            default_name="tts_output")
        path = dlg.result
        if not path: return

        # Reset export bar immediately on main thread
        self._export_progress_var.set(0)
        self._export_status_lbl.configure(text="Preparing...", fg=C["warning"])

        def _do():
            # ── Always re-synthesize the FULL text for export ─────────────────
            # Clear stop flag so export works after user pressed Stop.
            # stop_flag is only cleared by _on_speak, so export after stop
            # would otherwise exit the synthesis loop immediately.
            self._stop_flag.clear()
            self._wav_buffer.clear()
            chunks = voices.chunk_text(text)
            total  = max(len(chunks), 1)
            self.root.after(0, lambda: self._set_status("SYNTHESIZING FOR EXPORT...", C["warning"]))
            for i, chunk in enumerate(chunks):
                if self._stop_flag.is_set():
                    self.root.after(0, lambda: self._set_status("READY", C["success"]))
                    self.root.after(0, lambda: self._export_progress_var.set(0))
                    self.root.after(0, lambda: self._export_status_lbl.configure(text=""))
                    return
                try:
                    wav = voices.synthesize(chunk, engine, voice_name, speed, pitch)
                    self._wav_buffer.append(wav)
                    pct = (i + 1) / total * 75
                    self.root.after(0, lambda p=pct: self._export_progress_var.set(p))
                    self.root.after(0, lambda p=pct: self._export_status_lbl.configure(
                        text=f"Synthesizing {int(p)}% ({i+1}/{total} chunks)...",
                        fg=C["warning"]))
                except Exception as e:
                    bug_tracker.error(f"Export synth chunk {i}: {e}")
                    self.root.after(0, lambda err=str(e): self._dialog(
                        "Synthesis Error", f"Failed on chunk {i+1}:\n{err}", "error"))
                    self.root.after(0, lambda: self._set_status("READY", C["success"]))
                    self.root.after(0, lambda: self._export_progress_var.set(0))
                    self.root.after(0, lambda: self._export_status_lbl.configure(text=""))
                    return
            valid = [c for c in self._wav_buffer if c is not None]

            if not valid:
                self.root.after(0, lambda: self._dialog("Export Failed",
                    "No audio was synthesized. Check the voice engine is working.", "warn"))
                return

            # ── Write the file ────────────────────────────────────────────────
            self.root.after(0, lambda: self._set_status("EXPORTING WAV...", C["warning"]))
            self.root.after(0, lambda: self._export_status_lbl.configure(
                text="Writing WAV...", fg=C["warning"]))
            self.root.after(0, lambda: self._export_progress_var.set(80))
            try:
                os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            except Exception:
                pass
            ok = audio_handler.export_wav(valid, path)
            self.root.after(0, lambda: self._export_progress_var.set(100))

            # ── Verify ────────────────────────────────────────────────────────
            verified   = False
            file_size  = 0
            duration_s = 0.0
            if ok:
                try:
                    import wave as _wave
                    file_size = os.path.getsize(path)
                    with _wave.open(path, "rb") as wf:
                        frames     = wf.getnframes()
                        rate       = wf.getframerate()
                        duration_s = frames / rate if rate else 0
                    verified = frames > 0 and file_size > 44
                except Exception as e:
                    bug_tracker.warning(f"WAV verify: {e}")

            self.root.after(0, lambda: self._set_status("READY", C["success"]))
            if ok and verified:
                sz  = file_size // 1024
                dur = round(duration_s, 1)
                self.root.after(0, lambda: self._export_status_lbl.configure(
                    text=f"✓ {dur}s · {sz}KB saved", fg=C["success"]))
                self.root.after(0, lambda: self._dialog("Export WAV",
                    f"✓ Saved successfully\n\n"
                    f"File:     {path}\n"
                    f"Size:     {sz} KB\n"
                    f"Duration: {dur}s", "info"))
            elif ok and not verified:
                self.root.after(0, lambda: self._export_status_lbl.configure(
                    text="⚠ Saved but appears empty", fg=C["warning"]))
                self.root.after(0, lambda: self._dialog("Export WAV — Warning",
                    f"File saved but appears empty:\n{path}\n\n"
                    "Try pressing Speak first, then export.", "warn"))
            else:
                self.root.after(0, lambda: self._export_progress_var.set(0))
                self.root.after(0, lambda: self._export_status_lbl.configure(
                    text="✗ Export failed", fg=C["error"]))
                self.root.after(0, lambda: self._dialog("Export Failed",
                    f"Could not save WAV to:\n{path}\n\n"
                    "Check the folder is writable.", "error"))
            self.root.after(5000, lambda: self._export_progress_var.set(0))
            self.root.after(5000, lambda: self._export_status_lbl.configure(text=""))

        def _run_export():
            try:
                _do()
            finally:
                self._is_exporting = False
        threading.Thread(target=_run_export, daemon=True).start()

    def _export_mp3(self):
        """Export to MP3. All Tk calls on main thread — only synthesis/I/O in worker."""
        if self._is_speaking:
            self._dialog("Export Blocked",
                "Please press STOP before speaking ends, then export.", "warn")
            return
        if self._is_exporting:
            self._dialog("Already Exporting",
                "An export is already in progress. Please wait.", "warn")
            return
        # Pre-check ffmpeg on main thread before doing anything else
        import subprocess as _sp
        if _sp.run(["which", "ffmpeg"], capture_output=True).returncode != 0:
            self._dialog("ffmpeg Not Found",
                "MP3 export requires ffmpeg.\n\n"
                "Install it:\n  sudo apt install ffmpeg\n\n"
                "You can still export as WAV without ffmpeg.",
                "warn")
            return
        # Pre-validate on main thread
        text = self._get_text()
        if not text:
            self._dialog("Nothing to Export",
                "Please type or load a document first.", "warn")
            return
        idx = self._voice_combo.current()
        if idx < 0 or idx >= len(self._all_voices):
            return
        _, engine, voice_name = self._all_voices[idx]
        speed = self.speed_var.get()
        pitch = self.pitch_var.get()

        dlg = TTSSaveDialog(self.root, title="Export as MP3",
                            default_ext=".mp3",
                            filetypes=[("MP3 Audio", ".mp3"), ("WAV Audio", ".wav")],
                            default_name="tts_output")
        path = dlg.result
        if not path: return

        # Reset export bar on main thread immediately
        self._export_progress_var.set(0)
        self._export_status_lbl.configure(text="Preparing...", fg=C["warning"])
        self._is_exporting = True   # prevent concurrent speak

        def _do():
            try:
                _export_work()
            finally:
                self._is_exporting = False
                self.root.after(0, lambda: self._set_status("READY", C["success"]))

        def _export_work():
            self._stop_flag.clear()
            self._wav_buffer.clear()
            chunks = voices.chunk_text(text)
            total  = max(len(chunks), 1)
            self.root.after(0, lambda: self._set_status("SYNTHESIZING FOR EXPORT...", C["warning"]))
            for i, chunk in enumerate(chunks):
                if self._stop_flag.is_set():
                    self.root.after(0, lambda: self._set_status("READY", C["success"]))
                    self.root.after(0, lambda: self._export_progress_var.set(0))
                    self.root.after(0, lambda: self._export_status_lbl.configure(text=""))
                    return
                try:
                    wav = voices.synthesize(chunk, engine, voice_name, speed, pitch)
                    self._wav_buffer.append(wav)
                    pct = (i + 1) / total * 70
                    self.root.after(0, lambda p=pct: self._export_progress_var.set(p))
                    self.root.after(0, lambda p=pct: self._export_status_lbl.configure(
                        text=f"Synthesizing {int(p)}% ({i+1}/{total} chunks)...",
                        fg=C["warning"]))
                except Exception as e:
                    bug_tracker.error(f"MP3 synth chunk {i}: {e}")
                    self.root.after(0, lambda err=str(e): self._dialog(
                        "Synthesis Error", f"Failed on chunk {i+1}:\n{err}", "error"))
                    self.root.after(0, lambda: self._set_status("READY", C["success"]))
                    self.root.after(0, lambda: self._export_progress_var.set(0))
                    self.root.after(0, lambda: self._export_status_lbl.configure(text=""))
                    return
            valid = [c for c in self._wav_buffer if c is not None]

            if not valid:
                self.root.after(0, lambda: self._dialog("Export Failed",
                    "No audio was synthesized. Check the voice engine is working.", "warn"))
                return

            # ── Encode MP3 ────────────────────────────────────────────────────
            self.root.after(0, lambda: self._set_status("ENCODING MP3...", C["warning"]))
            self.root.after(0, lambda: self._export_status_lbl.configure(
                text="Encoding MP3 with ffmpeg...", fg=C["warning"]))
            self.root.after(0, lambda: self._export_progress_var.set(80))
            try:
                os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            except Exception:
                pass
            ok = audio_handler.export_mp3(valid, path)
            self.root.after(0, lambda: self._export_progress_var.set(100))

            # ── Verify ────────────────────────────────────────────────────────
            verified  = False
            file_size = 0
            if ok:
                try:
                    file_size = os.path.getsize(path)
                    verified  = file_size > 1024
                except Exception:
                    pass

            self.root.after(0, lambda: self._set_status("READY", C["success"]))
            if ok and verified:
                sz = file_size // 1024
                self.root.after(0, lambda: self._export_status_lbl.configure(
                    text=f"✓ {sz}KB MP3 saved", fg=C["success"]))
                self.root.after(0, lambda: self._dialog("Export MP3",
                    f"✓ Saved successfully\n\n"
                    f"File: {path}\n"
                    f"Size: {sz} KB", "info"))
            elif ok and not verified:
                self.root.after(0, lambda: self._export_status_lbl.configure(
                    text="⚠ Saved but appears empty", fg=C["warning"]))
                self.root.after(0, lambda: self._dialog("Export Warning",
                    f"File saved but appears empty:\n{path}\n\n"
                    "Check ffmpeg is working: ffmpeg -version", "warn"))
            else:
                self.root.after(0, lambda: self._export_progress_var.set(0))
                self.root.after(0, lambda: self._export_status_lbl.configure(
                    text="✗ Export failed", fg=C["error"]))
                self.root.after(0, lambda: self._dialog("Export Failed",
                    f"Could not save MP3 to:\n{path}\n\n"
                    "Check ffmpeg: sudo apt install ffmpeg", "error"))
            self.root.after(5000, lambda: self._export_progress_var.set(0))
            self.root.after(5000, lambda: self._export_status_lbl.configure(text=""))

        def _run_export():
            try:
                _do()
            finally:
                self._is_exporting = False
        threading.Thread(target=_run_export, daemon=True).start()

    # ── GPU ────────────────────────────────────────────────────────────────────
    def _get_best_provider(self):
        """Return (label, onnxruntime_provider) for the best available GPU."""
        avail = voices.get_available_providers()
        if "CUDAExecutionProvider"      in avail: return ("CUDA (NVIDIA)",  "CUDAExecutionProvider")
        if "ROCMExecutionProvider"      in avail: return ("ROCm (AMD)",     "ROCMExecutionProvider")
        if "TensorrtExecutionProvider"  in avail: return ("TensorRT",       "TensorrtExecutionProvider")
        if "OpenVINOExecutionProvider"  in avail: return ("OpenVINO (Intel iGPU)", "OpenVINOExecutionProvider")
        if "DmlExecutionProvider"       in avail: return ("DirectML",       "DmlExecutionProvider")
        return ("CPU", "CPUExecutionProvider")

    def _update_gpu_btn(self):
        prov = voices.get_current_provider()
        if prov == "CPUExecutionProvider":
            label, color, hover = "⚡ CPU", C["accent"], C["accent_dim"]
        elif "CUDA"     in prov: label, color, hover = "⚡ NVIDIA GPU ✓",   "#1a7a1a", "#22a022"
        elif "ROCM"     in prov: label, color, hover = "⚡ AMD GPU ✓",      "#1a7a1a", "#22a022"
        elif "Tensorrt" in prov: label, color, hover = "⚡ TensorRT ✓",     "#1a7a1a", "#22a022"
        elif "OpenVINO" in prov: label, color, hover = "⚡ Intel iGPU ✓",   "#1a7a1a", "#22a022"
        else:                    label, color, hover = "⚡ GPU ✓",           "#1a7a1a", "#22a022"
        self._gpu_btn.set_text(label)
        self._gpu_btn.set_colors(color, hover)
        self._gpu_btn._lbl.configure(fg="white")

    def _toggle_gpu(self):
        """Cycle CPU ↔ best available GPU. Stops synthesis first."""
        if self._is_speaking:
            self._stop_flag.set()
            audio_handler.stop_playback()
            import time; time.sleep(0.15)
            self._is_speaking = False
            self._wav_buffer.clear()
            self._set_status("READY", C["success"])
            self._speak_btn.set_colors(C["speak_bg"], C["speak_hover"])
            self.progress_var.set(0)

        prov = voices.get_current_provider()
        best_label, best_prov = self._get_best_provider()

        if prov == "CPUExecutionProvider":
            if best_prov != "CPUExecutionProvider":
                voices.set_provider(best_prov)
                self.cfg["provider"] = best_label
                save_config(self.cfg)
                self._update_gpu_btn()
                self._dialog("Compute Device",
                    f"Switched to {best_label} acceleration.\n"
                    "Model cache cleared — reloads on next Speak.", "info")
            else:
                avail = voices.get_available_providers()
                # Filter out cloud/non-GPU providers for the user-facing message
                cloud = {"AzureExecutionProvider", "CPUExecutionProvider"}
                local_gpu = [p for p in avail if p not in cloud]
                note = ""
                if "AzureExecutionProvider" in avail:
                    note = "\n(AzureExecutionProvider detected — this is cloud inference,\nnot a local GPU)"
                self._show_gpu_install_dialog(avail, note)
        else:
            voices.set_provider("CPUExecutionProvider")
            self.cfg["provider"] = "CPU"
            save_config(self.cfg)
            self._update_gpu_btn()


    def _show_gpu_install_dialog(self, avail: list, note: str = ""):
        """Show a dialog that explains GPU status and offers one-click install."""
        import subprocess as _sp, sys as _sys
        win = tk.Toplevel(self.root)
        win.title("GPU Acceleration")
        win.configure(bg=C["bg"])
        win.resizable(False, False)
        win.transient(self.root)
        win.geometry("480x380")

        # Header
        hdr = tk.Frame(win, bg=C["header_bg"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="⚡  GPU Acceleration",
                 font=("Courier New", 11, "bold"),
                 fg=C["accent2"], bg=C["header_bg"],
                 padx=20, pady=10).pack(side="left")
        tk.Frame(win, bg=C["border"], height=1).pack(fill="x")

        body = tk.Frame(win, bg=C["bg"], padx=20, pady=12)
        body.pack(fill="both", expand=True)

        cloud = {"AzureExecutionProvider", "CPUExecutionProvider"}
        local_gpu = [p for p in avail if p not in cloud]

        if note:
            tk.Label(body, text=note.strip(), font=("Courier New", 8),
                     fg=C["warning"], bg=C["bg"], wraplength=420,
                     justify="left").pack(anchor="w", pady=(0,8))

        tk.Label(body, text="No local GPU provider found. Install one for your hardware:",
                 font=("Courier New", 9), fg=C["text"], bg=C["bg"],
                 justify="left").pack(anchor="w", pady=(0,12))

        status_var = tk.StringVar(value="")
        status_lbl = tk.Label(body, textvariable=status_var,
                               font=("Courier New", 8, "bold"),
                               fg=C["success"], bg=C["bg"])
        status_lbl.pack(anchor="w", pady=(0,8))

        pip_path = str(Path(_sys.executable).parent / "pip")

        def _install(pkg, label):
            status_var.set(f"Installing {label}...")
            status_lbl.configure(fg=C["warning"])
            win.update()
            def _do():
                try:
                    r = _sp.run([pip_path, "install", pkg],
                                capture_output=True, text=True, timeout=180)
                    if r.returncode == 0:
                        self.root.after(0, lambda: status_var.set(
                            f"✓ {label} installed! Restart the app to use it."))
                        self.root.after(0, lambda: status_lbl.configure(fg=C["success"]))
                        bug_tracker.info(f"GPU package installed: {pkg}")
                    else:
                        err = r.stderr.strip()[-120:]
                        self.root.after(0, lambda: status_var.set(f"✗ Failed: {err}"))
                        self.root.after(0, lambda: status_lbl.configure(fg=C["error"]))
                        bug_tracker.error(f"GPU install failed {pkg}: {r.stderr[:300]}")
                except Exception as e:
                    self.root.after(0, lambda: status_var.set(f"✗ Error: {e}"))
                    self.root.after(0, lambda: status_lbl.configure(fg=C["error"]))
            threading.Thread(target=_do, daemon=True).start()

        GPU_OPTIONS = [
            ("NVIDIA GPU",    "onnxruntime-gpu",      "CUDA"),
            ("Intel iGPU",    "onnxruntime-openvino",  "OpenVINO"),
            ("AMD GPU",       "onnxruntime-rocm",      "ROCm"),
        ]
        for hw_label, pkg, _ in GPU_OPTIONS:
            row = tk.Frame(body, bg=C["surface"], padx=10, pady=6,
                           highlightthickness=1, highlightbackground=C["border"])
            row.pack(fill="x", pady=3)
            tk.Label(row, text=hw_label, font=("Courier New", 9, "bold"),
                     fg=C["text"], bg=C["surface"], width=14, anchor="w").pack(side="left")
            tk.Label(row, text=f"pip install {pkg}",
                     font=("Courier New", 8), fg=C["muted"],
                     bg=C["surface"]).pack(side="left", padx=(0,8))
            tk.Button(row, text="Install",
                      font=("Courier New", 8, "bold"),
                      bg=C["accent"], fg="white", relief="flat",
                      padx=8, pady=3, cursor="hand2",
                      activebackground=C["speak_hover"],
                      command=lambda p=pkg, l=hw_label: _install(p, l)
                      ).pack(side="right")

        tk.Label(body, text=f"Current providers: {', '.join(avail)}",
                 font=("Courier New", 7), fg=C["muted"],
                 bg=C["bg"], wraplength=420).pack(anchor="w", pady=(10,0))

        foot = tk.Frame(win, bg=C["surface"], pady=8)
        foot.pack(fill="x", side="bottom")
        tk.Button(foot, text="  Close  ",
                  font=("Courier New", 9, "bold"),
                  bg=C["surface2"], fg=C["text2"], relief="flat",
                  padx=12, pady=5, command=win.destroy,
                  activebackground=C["border"]).pack(side="right", padx=16)
        win.grab_set()

    def _show_gpu_dialog(self):
        import subprocess
        win = tk.Toplevel(self.root)
        win.title("Compute Device")
        win.configure(bg=C["bg"])
        win.geometry("540x360")
        win.resizable(False, False)
        win.transient(self.root)
        win.update()
        win.grab_set()

        tk.Label(win, text="⚡  Compute Device Status",
                 font=("Courier New",12,"bold"),
                 fg=C["accent2"], bg=C["bg"], pady=16).pack()
        tk.Frame(win, bg=C["border"], height=1).pack(fill="x", padx=20)

        avail = voices.get_available_providers()
        prov  = voices.get_current_provider()

        def prov_label(p):
            if "CUDA"    in p: return "NVIDIA CUDA GPU"
            if "OpenVINO" in p: return "Intel GPU (OpenVINO)"
            if "Dml"      in p: return "DirectML GPU"
            return "CPU"

        rows = [
            ("Active Provider",  prov_label(prov)),
            ("CUDA (NVIDIA)",    "✓ Available" if "CUDAExecutionProvider"     in avail else "✗ Not found"),
            ("OpenVINO (Intel)", "✓ Available" if "OpenVINOExecutionProvider" in avail else "✗ Not found"),
            ("All Providers",    ", ".join(avail)),
        ]
        try:
            r = subprocess.run(["nvidia-smi","--query-gpu=name,memory.total",
                                 "--format=csv,noheader"],
                                capture_output=True, text=True, timeout=3)
            rows.append(("NVIDIA GPU", r.stdout.strip() if r.returncode==0 else "Not detected"))
        except Exception:
            rows.append(("NVIDIA GPU", "nvidia-smi unavailable"))

        for label, val in rows:
            color = C["success"] if val.startswith("✓") else C["text"]
            row = tk.Frame(win, bg=C["surface"], padx=16, pady=7,
                           highlightthickness=1, highlightbackground=C["border"])
            row.pack(fill="x", padx=20, pady=3)
            tk.Label(row, text=label+":", font=("Courier New",9),
                     fg=C["text2"], bg=C["surface"],
                     width=20, anchor="w").pack(side="left")
            tk.Label(row, text=val, font=("Courier New",9,"bold"),
                     fg=color, bg=C["surface"],
                     wraplength=280, anchor="w").pack(side="left")

        # Intel GPU explanation
        hint = tk.Frame(win, bg=C["surface2"], padx=14, pady=10)
        hint.pack(fill="x", padx=20, pady=(8,0))
        tk.Label(hint, text="Why is GPU barely faster than CPU?",
                 font=("Courier New",8,"bold"),
                 fg=C["accent2"], bg=C["surface2"]).pack(anchor="w")
        tk.Label(hint,
                 text="Intel Iris Plus is an integrated GPU sharing system RAM.\n"
                      "Kokoro-82M is already fast on CPU (0.3s/chunk). The bottleneck\n"
                      "is the ONNX inference itself, not memory bandwidth.\n"
                      "Dedicated NVIDIA GPU would show 3-8× speedup.",
                 font=("Courier New",8),
                 fg=C["text2"], bg=C["surface2"],
                 justify="left").pack(anchor="w", pady=(2,6))
        tk.Label(hint, text="Enable Intel GPU (OpenVINO):",
                 font=("Courier New",8,"bold"),
                 fg=C["accent2"], bg=C["surface2"]).pack(anchor="w")
        tk.Label(hint,
                 text="pip install onnxruntime-openvino",
                 font=("Courier New",8),
                 fg=C["text2"], bg=C["surface2"]).pack(anchor="w", pady=(2,6))

        install_status = tk.StringVar(value="")
        install_lbl = tk.Label(hint, textvariable=install_status,
                               font=("Courier New",8,"bold"),
                               fg=C["success"], bg=C["surface2"])
        install_lbl.pack(anchor="w")

        def _install_openvino():
            import subprocess, sys
            install_status.set("Installing... please wait")
            install_lbl.configure(fg=C["warning"])
            win.update()
            try:
                # Find the venv pip or use sys.executable
                pip = str(Path(sys.executable).parent / "pip")
                result = subprocess.run(
                    [pip, "install", "onnxruntime-openvino"],
                    capture_output=True, text=True, timeout=120
                )
                if result.returncode == 0:
                    install_status.set("✓ Installed! Restart TTS Voices to use Intel GPU.")
                    install_lbl.configure(fg=C["success"])
                    bug_tracker.info("onnxruntime-openvino installed successfully")
                else:
                    install_status.set("✗ Failed: " + result.stderr.strip()[:80])
                    install_lbl.configure(fg=C["error"])
                    bug_tracker.error("openvino install failed: " + result.stderr[:200])
            except Exception as e:
                install_status.set(f"✗ Error: {e}")
                install_lbl.configure(fg=C["error"])

        btn_row = tk.Frame(hint, bg=C["surface2"])
        btn_row.pack(anchor="w", pady=(4,0))
        tk.Button(btn_row, text="⬇ Install OpenVINO Now",
                  font=("Courier New",9,"bold"),
                  bg=C["accent"], fg="white", relief="flat",
                  padx=12, pady=5, cursor="hand2",
                  activebackground=C["speak_hover"],
                  activeforeground="white",
                  command=lambda: threading.Thread(
                      target=_install_openvino, daemon=True).start()
                  ).pack(side="left", padx=(0,8))
        tk.Label(btn_row, text="(runs in your venv)",
                 font=("Courier New",7), fg=C["muted"],
                 bg=C["surface2"]).pack(side="left")

        foot_row = tk.Frame(win, bg=C["bg"])
        foot_row.pack(pady=10)
        tk.Button(foot_row, text="Close",
                  font=("Courier New",9,"bold"),
                  bg=C["surface2"], fg=C["text2"],
                  relief="flat", padx=16, pady=6,
                  command=win.destroy,
                  activebackground=C["border"],
                  activeforeground=C["text"]).pack()

    # ── Theme ──────────────────────────────────────────────────────────────────
    def _open_theme_picker(self):
        ThemePickerDialog(self.root, self._theme_key, self._apply_theme)

    def _apply_theme(self, theme_key: str):
        self._theme_key = theme_key
        C.update(THEMES[theme_key])
        self.cfg["theme"] = theme_key
        save_config(self.cfg)
        # Full UI rebuild with new colours
        for widget in self.root.winfo_children(): widget.destroy()
        self._style_ttk(); self._build_ui()
        self._load_voices(); self._refresh_engine_status(); self._update_gpu_btn()
        self.root.configure(bg=C["bg"])
        bug_tracker.info(f"Theme changed to: {theme_key}")

    # ── Nav helpers ────────────────────────────────────────────────────────────
    def _open_voice_library(self):
        from voice_library import VoiceLibraryWindow; VoiceLibraryWindow(self.root)

    def _open_bug_tracker(self):
        win=tk.Toplevel(self.root); win.title("Bug Tracker")
        win.geometry("680x500"); win.configure(bg=C["bg"])
        win.transient(self.root)   # group with main window — no separate taskbar icon
        tk.Label(win,text="⚐  Bug Tracker / Session Log",
                 font=("Courier New",11,"bold"),fg=C["accent2"],bg=C["bg"],pady=14).pack()
        tk.Label(win,text=f"Log: {bug_tracker.get_log_path()}",
                 font=("Courier New",8),fg=C["muted"],bg=C["bg"]).pack()
        txt=tk.Text(win,bg=C["surface"],fg=C["text"],font=("Courier New",9),
                    relief="flat",padx=12,pady=10)
        txt.pack(fill="both",expand=True,padx=12,pady=12)
        txt.insert("1.0",bug_tracker.get_report()); txt.configure(state="disabled")

    def _open_settings(self):
        win=tk.Toplevel(self.root); win.title("Settings")
        win.geometry("480x400"); win.configure(bg=C["bg"]); win.transient(self.root)
        tk.Label(win,text="⚙  Settings",font=("Courier New",12,"bold"),
                 fg=C["accent2"],bg=C["bg"],pady=14).pack()

        frm=tk.Frame(win,bg=C["surface"],padx=16,pady=12)
        frm.pack(fill="x",padx=16,pady=4)
        tk.Label(frm,text=f"Config:  {CONFIG_DIR}",
                 font=("Courier New",9),fg=C["text2"],bg=C["surface"]).pack(anchor="w")
        tk.Label(frm,text=f"Models:  {voices.MODELS_DIR}",
                 font=("Courier New",9),fg=C["text2"],bg=C["surface"]).pack(anchor="w",pady=(4,0))

        frm2=tk.Frame(win,bg=C["surface"],padx=16,pady=12)
        frm2.pack(fill="x",padx=16,pady=4)
        tk.Label(frm2,text="Chunk size (words):",
                 font=("Courier New",9),fg=C["text2"],bg=C["surface"]).pack(anchor="w")
        cv=tk.IntVar(value=self.cfg.get("chunk_words",200))
        tk.Scale(frm2,variable=cv,from_=50,to=500,orient="horizontal",
                 bg=C["surface"],fg=C["text"],troughcolor=C["surface2"],
                 highlightthickness=0,activebackground=C["accent"]).pack(fill="x")

        frm3=tk.Frame(win,bg=C["surface"],padx=16,pady=12)
        frm3.pack(fill="x",padx=16,pady=4)
        offset_lbl = tk.Label(frm3,
                 text=f"Highlight sync offset:  {self.cfg.get('highlight_offset',150)} ms",
                 font=("Courier New",9),fg=C["text2"],bg=C["surface"])
        offset_lbl.pack(anchor="w")
        tk.Label(frm3,
                 text="Higher = highlights wait longer (speech ahead of highlight)  |  Lower = highlights fire sooner (highlight ahead of speech)",
                 font=("Courier New",7),fg=C["muted"],bg=C["surface"],justify="left").pack(anchor="w")
        ov=tk.IntVar(value=self.cfg.get("highlight_offset",150))
        def _on_offset(*_):
            offset_lbl.configure(text=f"Highlight sync offset:  {ov.get()} ms")
        ov.trace_add("write", _on_offset)
        tk.Scale(frm3,variable=ov,from_=-200,to=500,orient="horizontal",
                 bg=C["surface"],fg=C["text"],troughcolor=C["surface2"],
                 highlightthickness=0,activebackground=C["accent"]).pack(fill="x")

        def _save():
            self.cfg["chunk_words"]=cv.get()
            self.cfg["highlight_offset"]=ov.get()
            save_config(self.cfg)
            win.destroy()
        GlowButton(win,text="Save",command=_save,normal_bg=C["accent"],
                   hover_bg=C["speak_hover"],fg="white").pack(pady=12)

    # ── Misc ───────────────────────────────────────────────────────────────────
    def _set_status(self,text,color=None):
        color=color or C["success"]
        self.status_var.set(text)
        self._status_pill.configure(fg=color,highlightbackground=color)

    def _apply_volume(self, *_):
        """Push current 0-100 volume to audio handler (maps to 0.0-1.0)."""
        try:
            vol_pct = max(0, min(100, self.volume_var.get()))
            audio_handler.set_volume_level(int(vol_pct * 327.67))
        except Exception:
            pass

    def _on_cfg_change(self, *_):
        """Debounced config change handler — actual disk write is deferred 800ms."""
        self.cfg["speed"]  = round(self.speed_var.get(), 2)
        self.cfg["pitch"]  = round(self.pitch_var.get(), 2)
        self.cfg["volume"] = max(0, min(100, self.volume_var.get()))
        self._apply_volume()
        # Debounce: cancel previous pending save, schedule a new one
        if hasattr(self, "_cfg_save_after_id") and self._cfg_save_after_id:
            try:
                self.root.after_cancel(self._cfg_save_after_id)
            except Exception:
                pass
        self._cfg_save_after_id = self.root.after(800, lambda: save_config(self.cfg))

    def _save_cfg_now(self): self._on_cfg_change(); save_config(self.cfg)

    def _on_close(self): self._stop_flag.set(); save_config(self.cfg); self.root.destroy()

    def run(self): self.root.mainloop()


def _global_exception_handler(exc_type, exc_value, exc_tb):
    """Catch any unhandled non-Tk exception and log it before crash."""
    import traceback as _tb
    tb_str = "".join(_tb.format_exception(exc_type, exc_value, exc_tb))
    bug_tracker.critical(f"Unhandled crash: {exc_value}", tb_str)
    sys.__excepthook__(exc_type, exc_value, exc_tb)


def _ensure_single_instance():
    """
    Prevent duplicate app windows when the icon is double-clicked.
    Uses an abstract Unix socket as a lock — automatically released
    when the process exits, no stale lock files left behind.
    Returns the socket (must stay alive) or None if already running.
    """
    import socket as _sock
    lock = _sock.socket(_sock.AF_UNIX, _sock.SOCK_STREAM)
    try:
        # Abstract namespace socket — starts with null byte, no file on disk
        lock.bind("\0ttsvoices_instance_lock")
        return lock   # We are the first instance — keep socket alive
    except OSError:
        # Another instance is already running — focus it via wmctrl if available
        import subprocess as _sp
        try:
            _sp.run(["wmctrl", "-a", "TTS Voices"], capture_output=True)
        except Exception:
            pass
        return None   # Signal caller to exit


if __name__ == "__main__":
    sys.excepthook = _global_exception_handler
    _lock = _ensure_single_instance()
    if _lock is None:
        sys.exit(0)   # Second instance — quit silently, first instance focused
    TTSVoicesApp().run()
