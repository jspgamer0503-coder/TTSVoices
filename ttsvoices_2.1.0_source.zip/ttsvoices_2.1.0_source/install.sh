#!/bin/bash
# ============================================================
#  TTS Voices 2.0 - Installation Script
#  Supports: Ubuntu, Kali Linux, Debian, Linux Mint
# ============================================================
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$APP_DIR/venv"
LAUNCHER="/usr/local/bin/ttsvoices"
DESKTOP_FILE="$HOME/.local/share/applications/ttsvoices.desktop"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

step()  { echo -e "\n${BLUE}▶ $1${NC}"; }
ok()    { echo -e "${GREEN}✓ $1${NC}"; }
warn()  { echo -e "${YELLOW}⚠ $1${NC}"; }
error() { echo -e "${RED}✗ $1${NC}"; exit 1; }

echo -e "${BLUE}"
echo "  ████████╗████████╗███████╗"
echo "  ╚══██╔══╝╚══██╔══╝██╔════╝"
echo "     ██║      ██║   ███████╗"
echo "     ██║      ██║   ╚════██║"
echo "     ██║      ██║   ███████║"
echo "     ╚═╝      ╚═╝   ╚══════╝"
echo -e "  TTS Voices 2.0 – Installer${NC}\n"

# ── 1. Check Python ──────────────────────────────────────────────────────
step "Checking Python 3.10+"
if ! command -v python3 &>/dev/null; then
    error "Python 3 not found. Install with: sudo apt install python3"
fi
PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PY_MAJOR=$(echo "$PY_VER" | cut -d. -f1)
PY_MINOR=$(echo "$PY_VER" | cut -d. -f2)
if [ "$PY_MAJOR" -lt 3 ] || ([ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 10 ]); then
    error "Python 3.10+ required, found $PY_VER"
fi
ok "Python $PY_VER found"

# ── 2. System dependencies ───────────────────────────────────────────────
step "Installing system dependencies"
if command -v apt-get &>/dev/null; then
    # Wait for any existing apt lock to clear (up to 60s)
    APT_LOCK_WAIT=0
    while sudo fuser /var/lib/apt/lists/lock /var/lib/dpkg/lock-frontend \
                    /var/lib/dpkg/lock &>/dev/null 2>&1; do
        if [ $APT_LOCK_WAIT -eq 0 ]; then
            echo "    Waiting for apt lock to clear (another process is using apt)..."
        fi
        APT_LOCK_WAIT=$((APT_LOCK_WAIT + 1))
        if [ $APT_LOCK_WAIT -ge 60 ]; then
            warn "apt lock held for 60s — skipping system package install."
            warn "Run manually: sudo apt-get install python3-venv python3-tk espeak-ng ffmpeg"
            break
        fi
        sleep 1
    done

    if [ $APT_LOCK_WAIT -lt 60 ]; then
        sudo apt-get update -qq 2>/dev/null || true
        sudo apt-get install -y -qq \
            python3-venv python3-tk python3-dev \
            espeak-ng ffmpeg alsa-utils \
            2>/dev/null && ok "System packages installed" \
                        || warn "Some packages may not have installed — try: sudo apt-get install python3-venv python3-tk espeak-ng ffmpeg"
    fi
else
    warn "apt-get not found. Please manually install: python3-venv python3-tk espeak-ng ffmpeg"
fi

# ── 3. Virtual environment ───────────────────────────────────────────────
step "Creating Python virtual environment"
if [ ! -d "$VENV_DIR" ]; then
    python3 -m venv "$VENV_DIR"
    ok "Virtual environment created at $VENV_DIR"
else
    ok "Virtual environment already exists"
fi

# ── 4. Activate venv ────────────────────────────────────────────────────
source "$VENV_DIR/bin/activate"

# ── 5. Upgrade pip ──────────────────────────────────────────────────────
step "Upgrading pip"
pip install --upgrade pip wheel --quiet
ok "pip upgraded"

# ── 6. Install Python dependencies ──────────────────────────────────────
step "Installing Python dependencies"

if pip install --quiet \
    soundfile \
    "requests>=2.32.3" \
    "urllib3>=2.2.3" \
    "charset-normalizer>=3.4.0" 2>/dev/null; then
    ok "Core network deps installed"
else
    warn "Some network deps failed"
fi
# pygame removed - using system aplay/paplay instead (lighter, faster startup)

step "Installing file extraction libraries"
pip install --quiet \
    pdfplumber \
    python-docx \
    ebooklib \
    beautifulsoup4 \
    striprtf \
    odfpy \
    pypdf \
    chardet 2>/dev/null
    ok "File extraction libs installed" || warn "Some extraction libs may be missing"

step "Installing Kokoro ONNX (primary TTS engine)"
pip install --quiet \
    kokoro-onnx \
    onnxruntime \
    numpy 2>/dev/null
    ok "Kokoro ONNX installed" || warn "Kokoro ONNX not available - will use espeak-ng fallback"

step "Installing Intel GPU support (OpenVINO)"
pip install --quiet onnxruntime-openvino \
    && ok "OpenVINO installed – Intel GPU acceleration available" \
    || warn "OpenVINO not available – CPU will be used (this is fine)"

step "Installing optional dependencies"
pip install --quiet pydub && ok "pydub installed" || warn "pydub not available (MP3 export may need ffmpeg)"

step "Installing password-protected file support"
if pip install --quiet msoffcrypto-tool pikepdf pycryptodome argon2-cffi 2>/dev/null; then
    ok "Encrypted file support installed (DOCX + PDF + ODT passwords, Argon2id for LO 24.8+)"
else
    warn "Some crypto libs failed — password-protected files may not open"
fi

# ── 7. Config directory ──────────────────────────────────────────────────
step "Creating config directories"
mkdir -p "$HOME/.ttsvoices/models"
mkdir -p "$HOME/.ttsvoices/logs"
ok "Config directories created at ~/.ttsvoices/"

# ── 8. Launcher script ───────────────────────────────────────────────────
step "Creating system launcher"
cat > /tmp/ttsvoices_launcher << EOF
#!/bin/bash
source "$VENV_DIR/bin/activate"
cd "$APP_DIR"
exec python3 "$APP_DIR/ttsvoices.py" "\$@"
EOF

if sudo cp /tmp/ttsvoices_launcher "$LAUNCHER" 2>/dev/null && \
   sudo chmod +x "$LAUNCHER"; then
    ok "Launcher installed at $LAUNCHER"
else
    # Install to user bin instead
    mkdir -p "$HOME/.local/bin"
    cp /tmp/ttsvoices_launcher "$HOME/.local/bin/ttsvoices"
    chmod +x "$HOME/.local/bin/ttsvoices"
    ok "Launcher installed at ~/.local/bin/ttsvoices"
fi

# ── 9. Desktop file ──────────────────────────────────────────────────────
step "Installing desktop entry"
mkdir -p "$(dirname "$DESKTOP_FILE")"
cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Name=TTS Voices
GenericName=Text to Speech
Comment=Unlimited Text-to-Speech Engine
Exec=$VENV_DIR/bin/python3 $APP_DIR/ttsvoices.py
Terminal=false
Type=Application
Categories=Accessibility;Audio;
Keywords=tts;speech;voice;text;
StartupNotify=true
EOF
ok "Desktop entry created"

# ── 10. Self-test ─────────────────────────────────────────────────────────
step "Running self-test"
python3 - << 'PYEOF'
import sys, subprocess
errors = []
# Check Tkinter
try:
    import tkinter
    print("  ✓ Tkinter available")
except ImportError:
    errors.append("tkinter missing: sudo apt install python3-tk")

# Check espeak-ng
r = subprocess.run(["which", "espeak-ng"], capture_output=True)
if r.returncode == 0:
    print("  ✓ espeak-ng available")
else:
    errors.append("espeak-ng missing: sudo apt install espeak-ng")

# Check Kokoro
try:
    import kokoro_onnx
    print("  ✓ Kokoro ONNX available")
except ImportError:
    print("  ⚠ Kokoro ONNX not installed (espeak-ng will be used)")

if errors:
    print("\nWarnings:")
    for e in errors:
        print(f"  ⚠ {e}")
else:
    print("  ✓ All checks passed!")
PYEOF

# ── Done ─────────────────────────────────────────────────────────────────
echo -e "\n${GREEN}╔════════════════════════════════════════╗"
echo "║  TTS Voices 2.0 installed successfully ║"
echo -e "╚════════════════════════════════════════╝${NC}"
echo ""
echo "  Run with:  ttsvoices"
echo "         or: python3 $APP_DIR/ttsvoices.py"
echo ""
echo "  For Kokoro ONNX voices, open the app and"
echo "  use Voice Library → Download All Required"
echo ""
