"""
TTS Voices 2.0 - Voice Library Module
GUI window for downloading and managing voice models.
"""
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import os
import urllib.request
from pathlib import Path
import bug_tracker

COLORS = {
    "bg":       "#0a0e1a",
    "surface":  "#111827",
    "surface2": "#0d1526",
    "border":   "#1e2d45",
    "border2":  "#223055",
    "accent":   "#1a6cf5",
    "accent2":  "#00d4ff",
    "accent_dim":"#0d3d99",
    "text":     "#e2e8f0",
    "text2":    "#8fa3c4",
    "muted":    "#64748b",
    "success":  "#22c55e",
    "warning":  "#f59e0b",
    "error":    "#ef4444",
    "speak_bg": "#1553d0",
    "speak_hover": "#1d6aff",
}

MODELS_DIR = Path.home() / ".ttsvoices" / "models"
MODELS_DIR.mkdir(parents=True, exist_ok=True)

# Correct download URLs from kokoro-onnx GitHub releases
KOKORO_MODELS = [
    {
        "name":     "Kokoro Model (v1.0)",
        "file":     "kokoro-v1.0.onnx",
        "url":      "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx",
        "size":     "~326 MB",
        "desc":     "Primary neural TTS model. Required for all Kokoro voices.",
        "required": True,
    },
    {
        "name":     "Voices Data (v1.0)",
        "file":     "voices-v1.0.bin",
        "url":      "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin",
        "size":     "~5 MB",
        "desc":     "Voice embeddings for all 11 Kokoro voices.",
        "required": True,
    },
]


class VoiceLibraryWindow:
    def __init__(self, parent):
        self.win = tk.Toplevel(parent)
        self.win.title("Voice Library")
        self.win.geometry("740x580")
        self.win.configure(bg=COLORS["bg"])
        self.win.resizable(True, True)
        self.win.transient(parent)   # share taskbar entry with parent
        self._build()

    def _build(self):
        # Header
        hdr = tk.Frame(self.win, bg=COLORS["surface"], pady=14)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Voice Library",
                 font=("Courier New", 14, "bold"),
                 fg=COLORS["accent2"], bg=COLORS["surface"]).pack(side="left", padx=20)
        tk.Label(hdr, text="Manage & download TTS voice models",
                 font=("Courier New", 9), fg=COLORS["muted"],
                 bg=COLORS["surface"]).pack(side="left", padx=8)

        # Models dir info
        tk.Label(self.win,
                 text=f"Models directory: {MODELS_DIR}",
                 font=("Courier New", 8), fg=COLORS["muted"],
                 bg=COLORS["bg"]).pack(anchor="w", padx=16, pady=(8, 0))

        # Tabs
        nb = ttk.Notebook(self.win)
        nb.pack(fill="both", expand=True, padx=12, pady=8)
        self._build_kokoro_tab(nb)
        self._build_engines_tab(nb)
        self._build_installed_tab(nb)

    def _build_kokoro_tab(self, nb):
        frame = tk.Frame(nb, bg=COLORS["bg"])
        nb.add(frame, text="  Kokoro ONNX  ")

        tk.Label(frame, text="Kokoro ONNX  -  Neural TTS (Apache 2.0)",
                 font=("Courier New", 11, "bold"),
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(frame,
                 text="High-quality offline neural voices. 82M parameters. Runs on CPU.",
                 font=("Courier New", 9), fg=COLORS["muted"],
                 bg=COLORS["bg"]).pack(anchor="w", padx=16, pady=(0, 12))

        self._progress_vars = {}
        self._status_labels = {}

        for m in KOKORO_MODELS:
            self._model_row(frame, m)

        # Download all button
        btn_frame = tk.Frame(frame, bg=COLORS["bg"])
        btn_frame.pack(pady=20)
        tk.Button(btn_frame, text="  Download All Required  ",
                  font=("Courier New", 10, "bold"),
                  bg=COLORS["accent"], fg="white", relief="flat",
                  padx=16, pady=8, cursor="hand2",
                  command=self._download_all,
                  activebackground="#1d6aff",
                  activeforeground="white").pack()

    def _model_row(self, parent, model):
        row = tk.Frame(parent, bg=COLORS["surface"], pady=12, padx=16,
                       highlightthickness=1,
                       highlightbackground=COLORS["border"])
        row.pack(fill="x", padx=16, pady=4)

        left = tk.Frame(row, bg=COLORS["surface"])
        left.pack(side="left", fill="both", expand=True)

        name_row = tk.Frame(left, bg=COLORS["surface"])
        name_row.pack(anchor="w")
        tk.Label(name_row, text=model["name"],
                 font=("Courier New", 10, "bold"),
                 fg=COLORS["text"], bg=COLORS["surface"]).pack(side="left")
        if model.get("required"):
            tk.Label(name_row, text="  required",
                     font=("Courier New", 8),
                     fg=COLORS["warning"], bg=COLORS["surface"]).pack(side="left")

        tk.Label(left, text=model["desc"],
                 font=("Courier New", 8),
                 fg=COLORS["muted"], bg=COLORS["surface"]).pack(anchor="w")

        installed = (MODELS_DIR / model["file"]).exists()
        status_text  = "  Installed" if installed else f"Not installed  ({model['size']})"
        status_color = COLORS["success"] if installed else COLORS["muted"]
        sl = tk.Label(left, text=status_text,
                      font=("Courier New", 8),
                      fg=status_color, bg=COLORS["surface"])
        sl.pack(anchor="w")
        self._status_labels[model["file"]] = sl

        # Progress bar
        pv = tk.DoubleVar()
        self._progress_vars[model["file"]] = pv
        ttk.Progressbar(left, variable=pv, maximum=100, length=340).pack(
            anchor="w", pady=(4, 0))

        # Download button (only if not installed)
        if not installed:
            tk.Button(row, text="Download",
                      font=("Courier New", 9),
                      bg=COLORS["accent"], fg="white", relief="flat",
                      padx=10, pady=4, cursor="hand2",
                      command=lambda m=model: self._download_one(m),
                      activebackground="#1d6aff",
                      activeforeground="white").pack(side="right", padx=8, anchor="center")

    def _download_one(self, model):
        threading.Thread(target=self._do_download, args=(model,), daemon=True).start()

    def _download_all(self):
        for m in KOKORO_MODELS:
            if not (MODELS_DIR / m["file"]).exists():
                threading.Thread(target=self._do_download, args=(m,), daemon=True).start()

    def _do_download(self, model):
        dest = MODELS_DIR / model["file"]
        sl   = self._status_labels.get(model["file"])
        pv   = self._progress_vars.get(model["file"])

        def set_status(txt, color):
            if sl:
                self.win.after(0, lambda t=txt, c=color: sl.config(text=t, fg=c))

        def set_progress(val):
            if pv:
                self.win.after(0, lambda v=val: pv.set(v))

        try:
            set_status("Connecting...", COLORS["warning"])
            headers = {"User-Agent": "TTSVoices/2.0"}
            req = urllib.request.Request(model["url"], headers=headers)
            # timeout=None means no timeout — needed for 326MB model on slow connections
            import time as _time
            with urllib.request.urlopen(req, timeout=None) as resp:
                total      = int(resp.getheader("Content-Length", 0))
                downloaded = 0
                t_start    = _time.monotonic()
                with open(dest, "wb") as f:
                    while True:
                        data = resp.read(131072)  # 128KB chunks for better speed
                        if not data:
                            break
                        f.write(data)
                        downloaded += len(data)
                        if total:
                            pct = 100 * downloaded / total
                            elapsed = max(0.001, _time.monotonic() - t_start)
                            speed_mb = (downloaded / elapsed) / (1024 * 1024)
                            done_mb  = downloaded / (1024 * 1024)
                            total_mb = total / (1024 * 1024)
                            set_status(
                                f"  {done_mb:.1f} / {total_mb:.1f} MB  ({speed_mb:.1f} MB/s)",
                                COLORS["warning"])
                            set_progress(pct)
                        else:
                            done_mb = downloaded / (1024 * 1024)
                            set_status(f"  {done_mb:.1f} MB downloaded...", COLORS["warning"])
            set_progress(100)
            set_status("  ✓ Installed", COLORS["success"])
            # Invalidate Kokoro singleton so new model is picked up on next Speak
            import voices as v_mod
            v_mod._kokoro_singleton.clear()
            bug_tracker.info(f"Downloaded: {model['name']}")
        except Exception as e:
            set_status(f"  Failed: {e}", COLORS["error"])
            bug_tracker.error(f"Model download failed {model['name']}: {e}")
            if dest.exists():
                os.unlink(dest)

    def _build_engines_tab(self, nb):
        """Engine comparison tab with install/check buttons for each engine."""
        outer = tk.Frame(nb, bg=COLORS["bg"])
        nb.add(outer, text="  Engines  ")

        tk.Label(outer, text="TTS Engine Comparison (2025)",
                 font=("Courier New", 11, "bold"),
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(outer,
                 text="Kokoro is installed and running. Below are other engines you can install for higher quality.",
                 font=("Courier New", 9), fg=COLORS["muted"],
                 bg=COLORS["bg"], wraplength=680, justify="left").pack(anchor="w", padx=16, pady=(0, 8))

        # Scrollable area for engine cards
        canvas = tk.Canvas(outer, bg=COLORS["bg"], highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=0)
        scrollbar = tk.Scrollbar(outer, orient="vertical", command=canvas.yview,
                                  bg=COLORS["surface"], width=10, relief="flat")
        scrollbar.place(relx=1, rely=0, relheight=1, anchor="ne")
        canvas.configure(yscrollcommand=scrollbar.set)

        frame = tk.Frame(canvas, bg=COLORS["bg"])
        cw = canvas.create_window((0, 0), window=frame, anchor="nw")
        frame.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(cw, width=e.width - 14))

        def _scroll(e):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(-1 if (e.num==4 or getattr(e,"delta",0)>0) else 1, "units")
            except Exception: pass
        canvas.bind("<Button-4>", _scroll)
        canvas.bind("<Button-5>", _scroll)
        frame.bind("<Button-4>",  _scroll)
        frame.bind("<Button-5>",  _scroll)

        ENGINES = [
            {
                "name":    "Kokoro ONNX v1.0",
                "badge":   "✓ INSTALLED",
                "badge_color": COLORS["success"],
                "quality": "★★★★☆",
                "size":    "326 MB",
                "license": "Apache 2.0",
                "desc":    "82M parameter neural TTS. Fastest offline engine. Runs on CPU or Intel GPU (OpenVINO). No internet needed.",
                "pro":     "Fast · Offline · CPU-friendly · 11 voices",
                "con":     "Not quite ElevenLabs quality at slow speeds",
                "pip":     None,
                "needs":   "Already installed",
                "installed_check": "kokoro_onnx",
            },
            {
                "name":    "Chatterbox TTS (0.5B)",
                "badge":   "GPU recommended",
                "badge_color": COLORS["warning"],
                "quality": "★★★★★",
                "size":    "~1.2 GB",
                "license": "MIT",
                "desc":    "Resemble AI's open-source model. Outperforms ElevenLabs in naturalness blind tests. Supports zero-shot voice cloning from a 5-second clip.",
                "pro":     "Best quality · Voice cloning · MIT license",
                "con":     "Slow on CPU (needs GPU for real-time)",
                "pip":     "chatterbox-tts",
                "needs":   "~2GB VRAM or ~6GB RAM",
                "installed_check": "chatterbox",
            },
            {
                "name":    "F5-TTS",
                "badge":   "GPU recommended",
                "badge_color": COLORS["warning"],
                "quality": "★★★★★",
                "size":    "~800 MB",
                "license": "MIT",
                "desc":    "Flow-matching based TTS with voice cloning. Very natural prosody. Can clone any voice from a short reference clip. State-of-the-art quality.",
                "pro":     "Voice cloning · Natural · MIT",
                "con":     "Requires CUDA GPU for real-time speed",
                "pip":     "f5-tts",
                "needs":   "CUDA GPU (4GB+ VRAM)",
                "installed_check": "f5_tts",
            },
            {
                "name":    "Dia 1.6B",
                "badge":   "High RAM needed",
                "badge_color": COLORS["error"],
                "quality": "★★★★★",
                "size":    "~3.2 GB",
                "license": "Apache 2.0",
                "desc":    "Nari Labs dialogue model. Ultra-realistic multi-speaker dialogue synthesis. Best-in-class for audiobooks and storytelling. English only.",
                "pro":     "Best audiobook quality · Multi-speaker · Apache 2.0",
                "con":     "Very large (3.2GB) · English only · Slow on CPU",
                "pip":     "git+https://github.com/nari-labs/dia.git",
                "needs":   "8GB+ RAM or 6GB+ VRAM",
                "installed_check": "dia",
            },
            {
                "name":    "XTTS-v2 (Coqui)",
                "badge":   "GPU recommended",
                "badge_color": COLORS["warning"],
                "quality": "★★★★☆",
                "size":    "~1.8 GB",
                "license": "Coqui Public",
                "desc":    "Coqui TTS XTTS-v2 supports 17 languages and zero-shot voice cloning. Well-established, large community, many pre-built voices available.",
                "pro":     "17 languages · Voice cloning · Large community",
                "con":     "Coqui license (non-commercial restrictions) · Large download",
                "pip":     "TTS",
                "needs":   "GPU recommended, CPU works slowly",
                "installed_check": "TTS",
            },
        ]

        self._engine_status = {}

        for eng in ENGINES:
            self._engine_card(frame, eng)

        tk.Label(frame,
                 text="Note: For your Intel Iris Plus iGPU system, Kokoro + OpenVINO is the optimal choice.\n"
                      "Chatterbox and F5-TTS require NVIDIA CUDA GPU for real-time performance.",
                 font=("Courier New", 8), fg=COLORS["accent2"],
                 bg=COLORS["bg"], wraplength=660, justify="left").pack(
            anchor="w", padx=16, pady=(10, 16))

    def _engine_card(self, parent, eng):
        """Render one engine card with install/check/remove buttons."""
        import importlib.util, sys

        # Check if installed
        check = eng.get("installed_check", "")
        try:
            installed = importlib.util.find_spec(check) is not None
        except Exception:
            installed = False
        # Kokoro is always installed in our context
        if eng["name"].startswith("Kokoro"):
            installed = True

        border_color = COLORS["success"] if installed else COLORS["border"]
        card = tk.Frame(parent, bg=COLORS["surface"], pady=12, padx=16,
                        highlightthickness=1, highlightbackground=border_color)
        card.pack(fill="x", padx=16, pady=5)

        # ── Header row ────────────────────────────────────────────────────
        hdr = tk.Frame(card, bg=COLORS["surface"])
        hdr.pack(fill="x")

        tk.Label(hdr, text=eng["name"],
                 font=("Courier New", 10, "bold"),
                 fg=COLORS["text"], bg=COLORS["surface"]).pack(side="left")
        tk.Label(hdr, text=f"  {eng['badge']}",
                 font=("Courier New", 8, "bold"),
                 fg=eng["badge_color"], bg=COLORS["surface"]).pack(side="left")

        # Stars + size + license on right
        meta = tk.Frame(hdr, bg=COLORS["surface"])
        meta.pack(side="right")
        tk.Label(meta, text=eng["quality"],
                 font=("Courier New", 9),
                 fg=COLORS["warning"], bg=COLORS["surface"]).pack(side="left", padx=(0,8))
        tk.Label(meta, text=f"{eng['size']} · {eng['license']}",
                 font=("Courier New", 8),
                 fg=COLORS["muted"], bg=COLORS["surface"]).pack(side="left")

        # ── Description ───────────────────────────────────────────────────
        tk.Label(card, text=eng["desc"],
                 font=("Courier New", 8),
                 fg=COLORS["text2"], bg=COLORS["surface"],
                 wraplength=640, justify="left").pack(anchor="w", pady=(4, 2))

        # ── Pro/Con row ───────────────────────────────────────────────────
        pc = tk.Frame(card, bg=COLORS["surface"])
        pc.pack(anchor="w")
        tk.Label(pc, text="✓ ", font=("Courier New",8,"bold"),
                 fg=COLORS["success"], bg=COLORS["surface"]).pack(side="left")
        tk.Label(pc, text=eng["pro"],
                 font=("Courier New",8), fg=COLORS["success"],
                 bg=COLORS["surface"]).pack(side="left", padx=(0,16))
        tk.Label(pc, text="✗ ", font=("Courier New",8,"bold"),
                 fg=COLORS["error"], bg=COLORS["surface"]).pack(side="left")
        tk.Label(pc, text=eng["con"],
                 font=("Courier New",8), fg=COLORS["error"],
                 bg=COLORS["surface"]).pack(side="left")

        # ── Requirements + buttons ────────────────────────────────────────
        bot = tk.Frame(card, bg=COLORS["surface"])
        bot.pack(fill="x", pady=(6, 0))

        tk.Label(bot, text=f"Requires: {eng['needs']}",
                 font=("Courier New", 8),
                 fg=COLORS["muted"], bg=COLORS["surface"]).pack(side="left")

        btn_frame = tk.Frame(bot, bg=COLORS["surface"])
        btn_frame.pack(side="right")

        status_var = tk.StringVar(value="✓ Installed" if installed else "")
        status_lbl = tk.Label(btn_frame, textvariable=status_var,
                               font=("Courier New",8,"bold"),
                               fg=COLORS["success"], bg=COLORS["surface"])
        status_lbl.pack(side="left", padx=(0,8))

        if eng["pip"] and not eng["name"].startswith("Kokoro"):
            pip_cmd = eng["pip"]

            def _do_install(cmd=pip_cmd, sv=status_var, sl=status_lbl, c=card):
                import subprocess, sys
                sv.set("Installing...")
                sl.configure(fg=COLORS["warning"])
                c.winfo_toplevel().update()
                try:
                    pip = str(Path(sys.executable).parent / "pip")
                    if cmd.startswith("git+"):
                        result = subprocess.run(
                            [pip, "install", cmd],
                            capture_output=True, text=True, timeout=300)
                    else:
                        result = subprocess.run(
                            [pip, "install", cmd],
                            capture_output=True, text=True, timeout=180)
                    if result.returncode == 0:
                        sv.set("✓ Installed! Restart app.")
                        sl.configure(fg=COLORS["success"])
                        c.configure(highlightbackground=COLORS["success"])
                    else:
                        sv.set("✗ Failed")
                        sl.configure(fg=COLORS["error"])
                        bug_tracker.error(f"Install {cmd} failed: {result.stderr[:300]}")
                except Exception as e:
                    sv.set(f"✗ Error: {str(e)[:40]}")
                    sl.configure(fg=COLORS["error"])

            def _do_uninstall(pkg=pip_cmd.split("/")[-1].replace(".git",""), sv=status_var, sl=status_lbl, c=card):
                import subprocess, sys
                sv.set("Uninstalling...")
                sl.configure(fg=COLORS["warning"])
                c.winfo_toplevel().update()
                try:
                    pip = str(Path(sys.executable).parent / "pip")
                    result = subprocess.run(
                        [pip, "uninstall", "-y", pkg],
                        capture_output=True, text=True, timeout=60)
                    if result.returncode == 0:
                        sv.set("Uninstalled")
                        sl.configure(fg=COLORS["muted"])
                        c.configure(highlightbackground=COLORS["border"])
                    else:
                        sv.set("✗ Failed")
                        sl.configure(fg=COLORS["error"])
                except Exception as e:
                    sv.set(f"✗ {str(e)[:40]}")

            if not installed:
                tk.Button(btn_frame,
                          text="⬇ Install",
                          font=("Courier New", 8, "bold"),
                          bg=COLORS["accent"], fg="white",
                          relief="flat", padx=10, pady=3,
                          cursor="hand2",
                          activebackground="#1d6aff",
                          activeforeground="white",
                          command=lambda fn=_do_install: threading.Thread(
                              target=fn, daemon=True).start()
                          ).pack(side="left", padx=2)
            else:
                tk.Button(btn_frame,
                          text="✕ Remove",
                          font=("Courier New", 8),
                          bg=COLORS["surface"], fg=COLORS["error"],
                          relief="flat", padx=10, pady=3,
                          cursor="hand2",
                          highlightthickness=1,
                          highlightbackground=COLORS["error"],
                          command=lambda fn=_do_uninstall: threading.Thread(
                              target=fn, daemon=True).start()
                          ).pack(side="left", padx=2)

        # pip command display
        if eng["pip"]:
            pip_row = tk.Frame(card, bg=COLORS["surface2"], padx=10, pady=4)
            pip_row.pack(fill="x", pady=(4,0))
            tk.Label(pip_row, text="pip install " + eng["pip"],
                     font=("Courier New", 8),
                     fg=COLORS["accent2"], bg=COLORS["surface2"]).pack(side="left")

    def _build_installed_tab(self, nb):
        frame = tk.Frame(nb, bg=COLORS["bg"])
        nb.add(frame, text="  Installed  ")

        tk.Label(frame, text="Installed Models",
                 font=("Courier New", 11, "bold"),
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(
            anchor="w", padx=16, pady=(14, 8))

        files = sorted(MODELS_DIR.iterdir()) if MODELS_DIR.exists() else []
        if not files:
            tk.Label(frame,
                     text="No models installed yet.\nDownload from the Kokoro ONNX tab.",
                     font=("Courier New", 10), fg=COLORS["muted"],
                     bg=COLORS["bg"], justify="center").pack(pady=60)
        else:
            for f in files:
                row = tk.Frame(frame, bg=COLORS["surface"], pady=8, padx=14,
                               highlightthickness=1,
                               highlightbackground=COLORS["border"])
                row.pack(fill="x", padx=16, pady=3)
                size_mb = f.stat().st_size / (1024 * 1024)
                tk.Label(row, text=f.name,
                         font=("Courier New", 10),
                         fg=COLORS["text"], bg=COLORS["surface"]).pack(side="left")
                tk.Label(row, text=f"{size_mb:.1f} MB",
                         font=("Courier New", 9),
                         fg=COLORS["muted"], bg=COLORS["surface"]).pack(side="right")
