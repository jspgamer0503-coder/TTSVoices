"""
TTS Voices 2.0 - Audio Handler (Lightweight Edition)
Uses system audio tools (aplay/paplay/ffplay) — no pygame dependency.
Zero import overhead, ~0MB extra RAM vs pygame's 30-60MB.
"""
import os
import io
import wave
import subprocess
import tempfile
import threading
import time
import bug_tracker

# ── Playback state ────────────────────────────────────────────────────────────
_current_volume = 0.63      # 0.0–1.0
_stop_event     = threading.Event()
_play_lock      = threading.Lock()
_current_proc   = None      # active subprocess for CLI playback
_poll_sleep     = threading.Event()  # reusable wait object for polling loops

# ── Playback timing for synchronized word highlighting ────────────────────────
_on_playback_start  = None   # callback: fired when audio actually starts
_on_playback_stop   = None   # callback: fired when audio stops
_playback_start_time = 0.0   # monotonic time when current chunk started

def set_callbacks(on_start=None, on_stop=None):
    """Register callbacks for playback timing (used by highlight sync)."""
    global _on_playback_start, _on_playback_stop
    _on_playback_start = on_start
    _on_playback_stop  = on_stop

def get_playback_position() -> float:
    """Return elapsed seconds since current chunk started playing."""
    global _playback_start_time
    if _current_proc is None or _current_proc.poll() is not None:
        return 0.0
    return time.monotonic() - _playback_start_time

def set_volume_level(volume_0_to_32767: int):
    global _current_volume
    _current_volume = max(0.0, min(1.0, volume_0_to_32767 / 32767.0))

def _apply_volume_to_wav(wav_data: bytes) -> bytes:
    """Scale PCM samples by _current_volume (pure Python, no deps)."""
    if _current_volume >= 0.99:
        return wav_data
    try:
        import struct, array as arr
        with wave.open(io.BytesIO(wav_data)) as wf:
            ch   = wf.getnchannels()
            sw   = wf.getsampwidth()
            sr   = wf.getframerate()
            pcm  = wf.readframes(wf.getnframes())
        if sw == 2:
            samples = arr.array('h', pcm)
            vol     = _current_volume
            vol_int = vol
            for i in range(len(samples)):
                samples[i] = max(-32768, min(32767, int(samples[i] * vol_int)))
            scaled_pcm = samples.tobytes()
        else:
            scaled_pcm = pcm  # skip non-16bit

        buf = io.BytesIO()
        with wave.open(buf, 'wb') as wf:
            wf.setnchannels(ch)
            wf.setsampwidth(sw)
            wf.setframerate(sr)
            wf.writeframes(scaled_pcm)
        return buf.getvalue()
    except Exception:
        return wav_data

def play_wav(wav_data: bytes) -> bool:
    """Play WAV bytes. Uses aplay → paplay → ffplay in order."""
    # Clear the stop flag once here — at the start of each new chunk.
    # _play_file no longer clears it, so stop_playback() always wins
    # if called between chunks.
    _stop_event.clear()
    scaled = _apply_volume_to_wav(wav_data)

    # Write to temp file (all CLI tools need a file path)
    tmp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
    try:
        tmp.write(scaled)
        tmp.flush()
        tmp.close()
        return _play_file(tmp.name)
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            pass

def _play_file(path: str) -> bool:
    """Try audio backends in order until one works."""
    global _current_proc

    # Verify the file has audio frames before attempting playback
    try:
        with wave.open(path, 'rb') as _wf:
            _frames = _wf.getnframes()
            _sr     = _wf.getframerate()
        if _frames == 0:
            bug_tracker.error(
                f"play_wav: WAV file has 0 frames — synthesis produced silent audio. "
                f"Check Kokoro model or try CPU mode."
            )
            return False
        bug_tracker.info(f"play_wav: {_frames} frames @ {_sr}Hz = {_frames/_sr:.2f}s")
    except Exception as _e:
        bug_tracker.warning(f"play_wav: could not verify WAV frames: {_e}")

    backends = [
        ["aplay",  "-q", path],
        ["paplay", path],
        ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path],
    ]

    tried = []
    for cmd in backends:
        tool = cmd[0]
        try:
            subprocess.run(["which", tool],
                           capture_output=True, check=True)
        except subprocess.CalledProcessError:
            continue  # tool not installed

        tried.append(tool)
        try:
            with _play_lock:
                # If stop was already requested, bail immediately — do NOT clear.
                # This fixes the "needs 2 clicks to stop" bug: previously clear()
                # wiped the flag set by stop_playback(), so the current chunk kept
                # playing and stop only took effect on the next chunk.
                if _stop_event.is_set():
                    return False
                proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                _current_proc = proc

            # Record ACTUAL start time and fire callback for highlight sync
            _playback_start_time = time.monotonic()
            if _on_playback_start:
                try: _on_playback_start()
                except Exception: pass

            # Poll so stop_playback() can interrupt
            while proc.poll() is None:
                if _stop_event.is_set():
                    proc.terminate()
                    try:
                        proc.wait(timeout=1)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                    return False
                _poll_sleep.wait(0.05)

            _current_proc = None
            if _on_playback_stop:
                try: _on_playback_stop()
                except Exception: pass

            if proc.returncode != 0:
                bug_tracker.warning(
                    f"Audio backend {tool} returned exit code {proc.returncode} — trying next"
                )
                continue  # ← FIX: try next backend instead of returning False

            return True

        except Exception as e:
            bug_tracker.warning(f"Audio backend {tool} failed: {e}")
            continue

    bug_tracker.error(f"All audio backends failed. Tried: {tried}")
    return False

def stop_playback():
    """
    Signal current playback to stop. Does NOT clear the flag — the flag is
    only cleared by _play_file() when starting a new playback cycle.
    """
    global _current_proc
    with _play_lock:
        _stop_event.set()
        proc = _current_proc
    if proc and proc.poll() is None:
        try:
            proc.terminate()
            try:
                proc.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                proc.kill()
        except Exception:
            pass

def export_wav(wav_chunks: list, output_path: str, progress_cb=None) -> bool:
    """Concatenate WAV chunks into a single output file.
    progress_cb(i) is called after each chunk is processed (optional).
    """
    if not wav_chunks:
        bug_tracker.warning("export_wav: empty chunk list")
        return False
    try:
        all_data    = b""
        sample_rate = None   # locked from FIRST valid chunk
        channels    = 1
        sampwidth   = 2
        valid_chunks = [c for c in wav_chunks if c is not None]
        for idx, chunk in enumerate(valid_chunks):
            try:
                with wave.open(io.BytesIO(chunk)) as wf:
                    if sample_rate is None:   # take header from first chunk only
                        sample_rate = wf.getframerate()
                        channels    = wf.getnchannels()
                        sampwidth   = wf.getsampwidth()
                    all_data   += wf.readframes(wf.getnframes())
            except Exception as e:
                bug_tracker.warning(f"Skipping corrupt chunk: {e}")
            if progress_cb:
                try:
                    progress_cb(idx)
                except Exception:
                    pass
        if not all_data:
            return False
        sample_rate = sample_rate or 24000
        with wave.open(output_path, 'wb') as out:
            out.setnchannels(channels)
            out.setsampwidth(sampwidth)
            out.setframerate(sample_rate)
            out.writeframes(all_data)
        return True
    except PermissionError as e:
        bug_tracker.error(f"WAV export permission denied: {e}")
        return False
    except OSError as e:
        bug_tracker.error(f"WAV export OS error: {e}")
        return False
    except Exception as e:
        bug_tracker.error(f"WAV export failed: {e}")
        return False

def export_mp3(wav_chunks: list, output_path: str, progress_cb=None) -> bool:
    """Export to MP3 using ffmpeg.
    progress_cb(i) is called after WAV stage completes (optional).
    """
    import tempfile as _tf
    tmp = _tf.mktemp(suffix='_tts_tmp.wav')
    if not export_wav(wav_chunks, tmp, progress_cb=progress_cb):
        return False
    try:
        result = subprocess.run(
            ["ffmpeg", "-y", "-i", tmp,
             "-codec:a", "libmp3lame", "-qscale:a", "2", output_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=120
        )
        os.unlink(tmp)
        return result.returncode == 0
    except Exception as e:
        bug_tracker.error(f"MP3 export failed: {e}")
        if os.path.exists(tmp):
            os.unlink(tmp)
        return False

def set_volume(vol_percent: int):
    """Legacy shim: accepts 0-100."""
    set_volume_level(int(vol_percent * 327.67))
