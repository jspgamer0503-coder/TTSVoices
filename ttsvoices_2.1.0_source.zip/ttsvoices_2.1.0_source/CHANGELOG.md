# TTS Voices — Changelog

## v2.1.0 (2026-03-29)

### Bug Fixes
- **Stop on first click** — voice now stops immediately on first click. Previously
  the stop flag was cleared inside the audio loop, requiring two clicks.
- **Highlight sync** — word highlights now sync to actual audio playback time via
  a 20ms real-time polling loop triggered by the audio start callback.
- **Voice Library** — fixed `_kokoro_cache` → `_kokoro_singleton.clear()` so newly
  downloaded models are picked up without restarting the app.
- **Tkinter crash** — fixed 8-digit hex colours (`#ffa50033`) that crashed on startup.

### New Features
- **Export progress bar** — progress bar and status label in the EXPORT panel
  showing time remaining, file size, and duration after save.
- **Export verification** — WAV exports verified by frame count; MP3 by file size.
  Distinct dialogs for success, empty file, and failure.
- **AMD GPU support** — ROCm execution provider added to GPU priority chain.
- **TensorRT support** — NVIDIA TensorRT provider added.
- **GPU button labels** — shows exact hardware: NVIDIA GPU / AMD GPU / Intel iGPU.
- **Yellow theme** — pure black background with electric yellow accents.
- **Golden theme** — pure black background making gold colours pop.
- **exceptions.py** — typed exception hierarchy for cleaner error handling.

### Removed Dependencies
- `soundfile` — unused; playback uses system `aplay`/`paplay`/`ffplay`
- `urllib3` — pulled in transitively by `requests`
- `charset-normalizer` — same; `chardet` used directly
- `odfpy` — XML fallback handles ODT without it
